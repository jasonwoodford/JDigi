/*
 * nmea.c
 * 
 * Copyright (c) 2018, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: nmea.c,v 0.9a 2018/09/25 00:19:00 NDT jason_woodford Exp $
 */

#include "nmea.h"

nmeaINFO    nmea_info;
nmeaSATINFO nmea_satinfo;

extern APRSConfig config;
extern APRSPosit position;

/**
 * 
 */
void nmeaInfoInit (void) {
    memset(&nmea_info, 0, sizeof(nmeaINFO));
    memset(&nmea_satinfo, 0, sizeof(nmeaSATINFO));
    nmeaTimeInfo();
}

/** Parse the checksum field and get the 8-bit value. 
 * @param str: pointer to a two byte ASCII string.
 * @param checksum: container pointer.
 * @return Zero on success or an error.
 */
int8_t nmeaParseChecksum (char *str, uint8_t *checksum) {
    int8_t i;
    char c;
    //
    for (i = 0; i < 2; ++i) {
        *checksum <<= 4;
        c = *(str + i);
        if ((c >= '0') && (c <= '9')) {
            *checksum |= c - '0';
        }
        else if ((c >= 'A') && (c <= 'F')) {
            *checksum |= c + 10 - 'A';
        }
        else {
            return NMEA_PARSERR_CRCR;
        }
    }
    return 0;
}

/** Parse the NMEA sentence and populate argv.
 * @param str: pointer to NMEA sentence.
 * @param argv: pointer table.
 * @return The number of parsed args NOT including the sentence type, or an error.
 */
int8_t nmeaParseSentence (char *str, uint8_t len, char **argv) {
    uint8_t crcc, crcr, flag, i;
    int8_t argc;
    //
    argc = 0;
    crcc = 0;
    crcr = 0;
    flag = FALSE;
    /* Sentences should be within defined a minimum and maximum.
     */
    if ((len < NMEA_STR_MIN) || (len > NMEA_STR_MAX)) return NMEA_PARSERR_SIZE;
    /* All sentences must begin with '$'.
     */
    if (*str != '$') return NMEA_PARSERR_START;
    /* Does the sentence have a CRC field?
     */
    if (*(str + len - 3) == '*') {
        len -= 3;
        // Set '*' delimiter to NULL.
        *(str + len) = 0;
        // Read Checksum.
        i = nmeaParseChecksum(str + len + 1, &crcr);
        if (i < 0) return i;
        // Calculate Checksum.
        for (i = 1; i < len; ++i) {
            crcc ^= *(str + i);
        }
        // Compare Checksums.
        if (crcc != crcr) return NMEA_PARSERR_CRCC;
    }
    /* Grab the start of each field, then set ',' delimiters to NULL.
     */
    for (i = 1; i < len; ++i) {
        // Get field pointer.
        if (!flag) {
            flag = TRUE;
            argv[argc] = str + i;
        }
        if (argc == NMEA_STR_FIELDS) return NMEA_PARSERR_FIELDS;
        // Is this the end of string?
        if (*(str + i) == 0) break;
        // Is this a ',' delimiter?
        if (*(str + i) == ',') {
            flag = FALSE;
            *(str + i) = 0;
            ++argc;
        }
    }
    return argc;
}

/** Parse a string for time.
 * @param str: string to be parsed. Format is HHMMSS[.d[dd]]
 * @param utc: pointer to a nmeaTIME structure.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseTime (char *str, nmeaTIME *utc) {
    uint8_t len, i;
    //
    if (*str == 0) return 0;
    len = strlen(str);
    switch (len) {
        case 6:
            // HHMMSS
            i = sscanf_P(str, PSTR("%2d%2d%2d"), &(utc->hour), &(utc->min), &(utc->sec));
            if (i == 3) return NMEA_VALID_TIME;
            break;
        case 8:
        case 9:
        case 10:
            // HHMMSS.d[dd]
            i = sscanf_P(str, PSTR("%2d%2d%2d.%d"), &(utc->hour), &(utc->min), &(utc->sec), &(utc->hsec));
            if (i == 4) return NMEA_VALID_TIME;
            break;
    }
    return NMEA_PARSERR_TIME;
}

/** Parse argv for a GPGGA sentence.
 * @param argc: arg count, NOT including the sentence type.
 * @param argv: pointer table.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseGPGGA (uint8_t argc, char **argv, nmeaGPGGA *gpgga) {
    int8_t i;
    //
    if (argc != NMEA_ARGC_GPGGA) return NMEA_PARSERR_GPGGA;
    memset(gpgga, 0, sizeof(nmeaGPGGA));
    i = nmeaParseTime(argv[1], &(gpgga->utc));
    if (i < 0) return i;
    if (*argv[2] == 0) return i;
    gpgga->lat = atof(argv[2]);
    if (*argv[3] == 0) return i;
    gpgga->ns = *argv[3];
    if (*argv[4] == 0) return i;
    gpgga->lon = atof(argv[4]);
    if (*argv[5] == 0) return i;
    gpgga->ew = *argv[5];
    gpgga->sig = atoi(argv[6]);
    gpgga->satinuse = atoi(argv[7]);
    gpgga->HDOP = atof(argv[8]);
    gpgga->elv = atof(argv[9]);
    gpgga->elv_units = *argv[10];
    gpgga->diff = atof(argv[11]);
    gpgga->diff_units = *argv[12];
    gpgga->dgps_age = atof(argv[13]);
    gpgga->dgps_sid = atoi(argv[14]);
    return (i | NMEA_VALID_POS);
}

/** Parse argv for a GPGSA sentence.
 * @param argc: arg count, NOT including the sentence type.
 * @param argv: pointer table.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseGPGSA (uint8_t argc, char **argv, nmeaGPGSA *gpgsa) {
    int8_t i;
    //
    if (argc != NMEA_ARGC_GPGSA) return NMEA_PARSERR_GPGSA;
    memset(gpgsa, 0, sizeof(nmeaGPGSA));
    gpgsa->fix_mode = *argv[1];
    gpgsa->fix_type = atoi(argv[2]);
    for (i = 0; i < NMEA_MAXSAT; ++i) {
        gpgsa->sat_prn[i] = atoi(argv[i+3]);
    }
    gpgsa->PDOP = atof(argv[15]);
    gpgsa->HDOP = atof(argv[16]);
    gpgsa->VDOP = atof(argv[17]);
    return 0;
}

/** Parse argv for a GPGSV sentence.
 * @param argc: arg count, NOT including the sentence type.
 * @param argv: pointer table.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseGPGSV (uint8_t argc, char **argv, nmeaGPGSV *gpgsv) {
    int8_t i, j;
    //
    if ((argc < NMEA_ARGC_GPGSV_MIN) || (argc > NMEA_ARGC_GPGSV_MAX)) return NMEA_PARSERR_GPGSV;
    memset(gpgsv, 0, sizeof(nmeaGPGSV));
    gpgsv->pack_count = atoi(argv[1]);
    gpgsv->pack_index = atoi(argv[2]);
    gpgsv->sat_count = atoi(argv[3]);
    j = gpgsv->sat_count - ((gpgsv->pack_index - 1) * NMEA_SATINPACK);
    if (j > NMEA_SATINPACK) j = NMEA_SATINPACK;
    for (i = 0; i < j; ++i) {
        gpgsv->sat_data[i].id = atoi(argv[i+4]);
        gpgsv->sat_data[i].elv = atoi(argv[i+4]);
        gpgsv->sat_data[i].azimuth = atoi(argv[i+4]);
        gpgsv->sat_data[i].sig = atoi(argv[i+4]);
    }
    return 0;
}

/** Parse argv for a GPGLL sentence.
 * @param argc: arg count, NOT including the sentence type.
 * @param argv: pointer table.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseGPGLL (uint8_t argc, char **argv, nmeaGPGLL *gpgll) {
    int8_t i;
    //
    if ((argc < NMEA_ARGC_GPGLL_MIN) && (argc > NMEA_ARGC_GPGLL_MAX)) return NMEA_PARSERR_GPGLL;
    memset(gpgll, 0, sizeof(nmeaGPGLL));
    if (*argv[1] == 0) return 0;
    gpgll->lat = atof(argv[1]);
    if (*argv[2] == 0) return 0;
    gpgll->ns = *argv[2];
    if (*argv[3] == 0) return 0;
    gpgll->lon = atof(argv[3]);
    if (*argv[4] == 0) return 0;
    gpgll->ew = *argv[4];
    i = nmeaParseTime(argv[5], &(gpgll->utc));
    if (i < 0) return i;
    gpgll->valid = *argv[6];
    return (i | NMEA_VALID_POS);
}

/** Parse argv for a GPRMC sentence.
 * @param argc: arg count, NOT including the sentence type.
 * @param argv: pointer table.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseGPRMC (uint8_t argc, char **argv, nmeaGPRMC *gprmc) {
    int8_t i;
    //
    if (argc != NMEA_ARGC_GPRMC) return NMEA_PARSERR_GPRMC;
    memset(gprmc, 0, sizeof(nmeaGPRMC));
    i = nmeaParseTime(argv[1], &(gprmc->utc));
    if (i < 0) return i;
    gprmc->status = *argv[2];
    if (*argv[3] == 0) return i;
    gprmc->lat = atof(argv[3]);
    if (*argv[4] == 0) return i;
    gprmc->ns = *argv[4];
    if (*argv[5] == 0) return i;
    gprmc->lon = atof(argv[5]);
    if (*argv[6] == 0) return i;
    gprmc->ew = *argv[6];
    gprmc->speed = atof(argv[7]);
    gprmc->direction = atof(argv[8]);
    gprmc->declination = atof(argv[9]);
    gprmc->declin_ew = *argv[10];
    gprmc->mode = *argv[11];
    return (i | NMEA_VALID_POS);
}

/** Parse argv for a GPVTG sentence.
 * @param argc: arg count, NOT including the sentence type.
 * @param argv: pointer table.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseGPVTG (uint8_t argc, char **argv, nmeaGPVTG *gpvtg) {
    if (argc != NMEA_ARGC_GPVTG) return NMEA_PARSERR_GPVTG;
    memset(gpvtg, 0, sizeof(nmeaGPVTG));
    gpvtg->dir = atof(argv[1]);
    gpvtg->dir_t = *argv[2];
    gpvtg->dec = atof(argv[3]);
    gpvtg->dec_m = *argv[4];
    gpvtg->spn = atof(argv[5]);
    gpvtg->spn_n = *argv[6];
    gpvtg->spk = atof(argv[7]);
    gpvtg->spk_k = *argv[8];
    return 0;
}

/** Parse argv for a GPZDA sentence.
 * @param argc: arg count, NOT including the sentence type.
 * @param argv: pointer table.
 * @return Flags on success (7-bit) or an error (negative).
 */
int8_t nmeaParseGPZDA (uint8_t argc, char **argv, nmeaTIME *t) {
    int8_t i;
    //
    if (argc != NMEA_ARGC_GPZDA) return NMEA_PARSERR_GPZDA;
    memset(t, 0, sizeof(nmeaTIME));
    i = nmeaParseTime(argv[1], t);
    if (i < 0) return i;
    t->day = atoi(argv[2]);
    t->mon = atoi(argv[3]);
    t->year = atoi(argv[4]);
    if ((t->day > 0) && (t->mon > 0) && (t->year >= 1900)) {
        t->year -= 1900;
        return (i | NMEA_VALID_DATE);
    }
    return i;
}

/**********************************************************/

/** Copy GPGGA data from temporary to global structure.
 * @param p: pointer to GPGGA structure.
 */
void nmeaGPGGAInfo (nmeaGPGGA *p, int8_t flags) {
    nmeaInfoSetTime(&p->utc, flags);
    nmea_info.sig = p->sig;
    nmea_info.HDOP = p->HDOP;
    nmea_info.elv = p->elv;
    nmea_info.position.lat = ((p->ns == 'N') ? p->lat : -(p->lat));
    nmea_info.position.lon = ((p->ew == 'E') ? p->lon : -(p->lon));
}

/** Copy GPGSA data from temporary to global structure.
 * @param p: pointer to GPGSA structure.
 */
void nmeaGPGSAInfo (nmeaGPGSA *p, int8_t flags) {
    int i, j, nuse;
    //
    nuse = 0;
    nmea_info.fix = p->fix_type;
    nmea_info.PDOP = p->PDOP;
    nmea_info.HDOP = p->HDOP;
    nmea_info.VDOP = p->VDOP;
    for (i = 0; i < NMEA_MAXSAT; ++i) {
        for (j = 0; j < nmea_info.satinfo.inview; ++j) {
            if (p->sat_prn[i] && (p->sat_prn[i] == nmea_info.satinfo.sat[j].id)) {
                nmea_info.satinfo.sat[j].in_use = 1;
                nuse++;
            }
        }
    }
    nmea_info.satinfo.inuse = nuse;
}

/** Copy GPGSV data from temporary to global structure.
 * @param p: pointer to GPGSV structure.
 */
void nmeaGPGSVInfo (nmeaGPGSV *p, int8_t flags) {
    int isat, isi, nsat;
    //
    if ((p->pack_index > p->pack_count) || ((p->pack_index * NMEA_SATINPACK) > NMEA_MAXSAT)) return;
    if (p->pack_index < 1) p->pack_index = 1;
    nmea_info.satinfo.inview = p->sat_count;
    nsat = (p->pack_index - 1) * NMEA_SATINPACK;
    nsat = (nsat + NMEA_SATINPACK > p->sat_count) ? p->sat_count - nsat : NMEA_SATINPACK;
    for (isat = 0; isat < nsat; ++isat) {
        isi = (p->pack_index - 1) * NMEA_SATINPACK + isat;
        nmea_info.satinfo.sat[isi].id = p->sat_data[isat].id;
        nmea_info.satinfo.sat[isi].elv = p->sat_data[isat].elv;
        nmea_info.satinfo.sat[isi].azimuth = p->sat_data[isat].azimuth;
        nmea_info.satinfo.sat[isi].sig = p->sat_data[isat].sig;
    }
}

/**
 */
void nmeaGPGLLInfo (nmeaGPGLL *p, int8_t flags) {
    if (p->valid == 'A') {
        nmea_info.position.lat = ((p->ns == 'N') ? p->lat : -(p->lat));
        nmea_info.position.lon = ((p->ew == 'E') ? p->lon : -(p->lon));
        nmeaInfoSetTime(&p->utc, flags);
    }
}
/** Copy GPRMC data from temporary to global structure.
 * @param p: pointer to GPRMC structure.
 */
void nmeaGPRMCInfo (nmeaGPRMC *p, int8_t flags) {
    if (p->status == 'A') {
        if (nmea_info.sig == NMEA_SIG_BAD) nmea_info.sig = NMEA_SIG_MID;
        if (nmea_info.fix == NMEA_FIX_BAD) nmea_info.fix = NMEA_FIX_2D;
    }
    else if (p->status == 'V') {
        nmea_info.sig = NMEA_SIG_BAD;
        nmea_info.fix = NMEA_FIX_BAD;
    }
    nmeaInfoSetTime(&p->utc, flags);
    nmea_info.position.lat = ((p->ns == 'N') ? p->lat : -(p->lat));
    nmea_info.position.lon = ((p->ew == 'E') ? p->lon : -(p->lon));
    nmea_info.speed = p->speed * NMEA_CONV_KNOT;
    nmea_info.direction = p->direction;
}

/** Copy GPVTG data from temporary to global structure.
 * @param p: pointer to GPVTG structure.
 */
void nmeaGPVTGInfo (nmeaGPVTG *p, int8_t flags) {
    nmea_info.direction = p->dir;
    nmea_info.declination = p->dec;
    nmea_info.speed = p->spk;
}

/** Copy UTC data from temporary to global structure. Also used to set GPZDA Info.
 * @param p: pointer to nmeaTIME structure.
 */
void nmeaInfoSetTime (nmeaTIME *p, int8_t flags) {
    if (flags & NMEA_VALID_DATE) {
        nmea_info.utc.day = p->day;
        nmea_info.utc.mon = p->mon;
        nmea_info.utc.year = p->year;
    }
    if (flags & NMEA_VALID_TIME) {
        nmea_info.utc.hsec = p->hsec;
        nmea_info.utc.sec = p->sec;
        nmea_info.utc.min = p->min;
        nmea_info.utc.hour = p->hour;
    }
}

/************************************************/

/** Put a UTC timestamp into the global structure.
 */
void nmeaTimeInfo (void) {
    struct tm stm;
    time_t timer;
    //
    timer = time(NULL);
    gmtime_r(&timer, &stm);
    nmea_info.utc.sec = stm.tm_sec;
    nmea_info.utc.min = stm.tm_min;
    nmea_info.utc.hour = stm.tm_hour;
    nmea_info.utc.day = stm.tm_mday;
    nmea_info.utc.mon = stm.tm_mon;
    nmea_info.utc.year = stm.tm_year;
}

/** Set the system position/date/time using the GPS data.
 */
void nmeaInfoPosTime (int8_t flags) {
    struct  tm stm;
    time_t  timer0, timer1;
    int32_t timed;
    //
    timer0 = time(NULL);
    //
    if (flags & NMEA_VALID_POS) {
//        fputs_P(PSTR("\n## POSITION UPDATE ##"), stderr);
        position.latitudeD = (int8_t) (nmea_info.position.lat / 100.0);
        position.latitudeM = fmod(nmea_info.position.lat, 100.0);
        position.longitudeD = (int16_t) (nmea_info.position.lon / 100.0);
        position.longitudeM = fmod(nmea_info.position.lon, 100.0);
    }
    //
    if (((nmea_info.ctimer - timer0) < 0) || ((nmea_info.ctimer - timer0) > ONE_HOUR)) {
        nmea_info.ctimer = timer0 + NMEA_TIME_FREQ;
        gmtime_r(&timer0, &stm);
        if (flags & (NMEA_VALID_TIME | NMEA_VALID_DATE)) {
            if (flags & NMEA_VALID_TIME) {
//                fputs_P(PSTR("\n## TIME UPDATE ##"), stderr);
                stm.tm_sec = nmea_info.utc.sec;
                stm.tm_min = nmea_info.utc.min;
                stm.tm_hour = nmea_info.utc.hour;
            }
            if (flags & NMEA_VALID_DATE) {
//                fputs_P(PSTR("\n## DATE UPDATE ##"), stderr);
                stm.tm_mday = nmea_info.utc.day;
                stm.tm_mon = nmea_info.utc.mon;
                stm.tm_year = nmea_info.utc.year;
            } else {
                //
            }
            timer1 = mk_gmtime(&stm);
            localtime_r(&timer1, &stm);
            timer1 = mktime(&stm);
/*            fprintf_P(stderr, PSTR("\n## GPS Time: %d-%d-%d %02d:%02d:%02d [%ld] ##"),
                      stm.tm_year + 1900, stm.tm_mon + 1, stm.tm_mday,
                      stm.tm_hour, stm.tm_min, stm.tm_sec, timer1);
*/            
            localtime_r(&timer0, &stm);
/*            fprintf_P(stderr, PSTR("\n## SYS Time: %d-%d-%d %02d:%02d:%02d [%ld] ##"),
                      stm.tm_year + 1900, stm.tm_mon + 1, stm.tm_mday,
                      stm.tm_hour, stm.tm_min, stm.tm_sec, timer0);
*/            
            // Update if local clock is more than NMEA_TIME_DRIFT seconds off.
            timed = timer1 - timer0;
            if (timed < 0) timed = -timed;
            if (timed > NMEA_TIME_DRIFT) {
                set_system_time(timer1);
                beaconReset();
//                fputs_P(PSTR("\n## CLOCK UPDATE ##"), stderr);
            }
        }
    }
}

/** Print an error message to stderr.
 * @param errno: error number.
 */
void nmeaPrintError (int8_t nmeaerrno) {
    fputs_P(PSTR("\nNMEA: "), stderr);
    switch (nmeaerrno) {
        case NMEA_PARSERR_SIZE:
            fputs_P(PSTR("Bad Size"), stderr);
            break;
        case NMEA_PARSERR_START:
            fputs_P(PSTR("Bad Start"), stderr);
            break;
        case NMEA_PARSERR_CRCR:
            fputs_P(PSTR("Bad RX CRC"), stderr);
            break;
        case NMEA_PARSERR_CRCC:
            fputs_P(PSTR("Bad Calculated CRC"), stderr);
            break;
        case NMEA_PARSERR_FIELDS:
            fputs_P(PSTR("Too Many Fields"), stderr);
            break;
        case NMEA_PARSERR_TIME:
            fputs_P(PSTR("Bad Time"), stderr);
            break;
        case NMEA_PARSERR_GPGGA:
            fputs_P(PSTR("Bad GPGGA"), stderr);
            break;
        case NMEA_PARSERR_GPGSA:
            fputs_P(PSTR("Bad GPGSA"), stderr);
            break;
        case NMEA_PARSERR_GPGSV:
            fputs_P(PSTR("Bad GPGSV"), stderr);
            break;
        case NMEA_PARSERR_GPRMC:
            fputs_P(PSTR("Bad GPRMC"), stderr);
            break;
        case NMEA_PARSERR_GPVTG:
            fputs_P(PSTR("Bad GPVTG"), stderr);
            break;
        case NMEA_UNKNOWN_TYPE:
            fputs_P(PSTR("Unknown Sentence type"), stderr);
            break;
        default:
            fprintf_P(stderr, PSTR("[%d]"), nmeaerrno);
            break;
    }
}
