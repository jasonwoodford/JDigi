/*
 * threadShell.c
 * 
 * Copyright (c) 2018, Jason Woodford, VO1JWW. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: threadShell.c,v 0.9a 2018/08/20 21:46:00 NDT jason_woodford Exp $
 */

#include "threads.h"

static uint8_t bufGPS[GPS_STATIC_SIZE]; ///< GPS static buffer.
//static char bufGPSRx[128];   ///< GPS incoming static buffer.

extern FILE fstrUart2;  ///< GPS UART.
extern nmeaINFO    nmea_info;
extern nmeaSATINFO nmea_satinfo;

/** GPS thread.
 * This infinite loop reads a NMEA sentence (GPS unit, etc.) and parses it.
 * All sentences should end with CR-LF (\r\n) and be error-free, else
 * the buffer is reset and the loop starts over.
 */
void threadGPS (uint32_t data) {
    uint8_t argc, len, flag;
    int8_t i;
    char **argv, *p, *q;
    int c;
    //
    p = (char*) bufGPS;
    while (TRUE) {
        flag = 0;
        len = 0;
        while (flag != NMEA_RXFLAG_CRLF) {
            // Capture input.
            c = fgetc(&fstrUart2);
            switch (c) {
                case _FDEV_EOF:
                    fputs_P(PSTR("\n*GPS RX EOF Error*\n"), stderr);
                    flag = NMEA_RXFLAG_RESET;
                    break;
                case _FDEV_ERR:
                    fputs_P(PSTR("\n*GPS RX ERR Error*\n"), stderr);
                    flag = NMEA_RXFLAG_RESET;
                    break;
                case '\r':
                    // a CR signifies first end of sentence char.
                    flag = NMEA_RXFLAG_CR;
                    break;
                case '\n':
                    // a LF signifies second end of sentence char.
                    if (flag != NMEA_RXFLAG_CR) {
                        fputs_P(PSTR("\n*GPS Bad CR/LF Error*\n"), stderr);
                        flag = NMEA_RXFLAG_RESET;
                    } else {
                        // we have a CR/LF pair. Ready to parse.
                        flag = NMEA_RXFLAG_CRLF;
                        *(p + len++) = 0;
                    }
                    break;
                default:
                    // fill buffer with data.
                    *(p + len++) = (char) c;
            }
            if (len > (NMEA_STR_MAX + 1)) {
                fputs_P(PSTR("\n*GPS RX Buffer Overflow*\n"), stderr);
                flag = NMEA_RXFLAG_RESET;
            }
            // All RX errors are reset here.
            if (flag == NMEA_RXFLAG_RESET) {
                flag = 0;
                len = 0;
            }
        }
        // Parse the received sentence.
        if (len > 0) {
            // ECHO FOR DEBUG.
//            fputs_P(PSTR("\r\n"), stderr);
//            fputs(p, stderr);
            // Set aside room for the arg pointers.
            q = p + (len * sizeof(char));
            argv = (char**) q;
            // Parse the sentence to get all arguments.
            i = nmeaParseSentence(p, len, argv);
            if (i < 0) { nmeaPrintError(i); }
            else {
                argc = (uint8_t) i;
                // Set aside room for the structure to be populated.
                q += argc * sizeof(argv);
                // Compare the first arg with a sentence type.
                if (strcmp_P(argv[0], PSTR("GPGGA")) == 0) {
                    i = nmeaParseGPGGA(argc, argv, (nmeaGPGGA*) q);
                    if (i < 0) { nmeaPrintError(i); }
                    else {
                        nmeaGPGGAInfo((nmeaGPGGA*) q, i);
                        nmeaInfoPosTime(i);
                    }
                }
                else if (strcmp_P(argv[0], PSTR("GPGSA")) == 0) {
                    i = nmeaParseGPGSA(argc, argv, (nmeaGPGSA*) q);
                    if (i < 0) { nmeaPrintError(i); }
                    else {
                        nmeaGPGSAInfo((nmeaGPGSA*) q, i);
                    }
                }
                else if (strcmp_P(argv[0], PSTR("GPGSV")) == 0) {
                    i = nmeaParseGPGSV(argc, argv, (nmeaGPGSV*) q);
                    if (i < 0) { nmeaPrintError(i); }
                    else {
                        nmeaGPGSVInfo((nmeaGPGSV*) q, i);
                    }
                }
                else if (strcmp_P(argv[0], PSTR("GPGLL")) == 0) {
                    i = nmeaParseGPGLL(argc, argv, (nmeaGPGLL*) q);
                    if (i < 0) { nmeaPrintError(i); }
                    else {
                        nmeaGPGLLInfo((nmeaGPGLL*) q, i);
                    }
                }
                else if (strcmp_P(argv[0], PSTR("GPRMC")) == 0) {
                    i = nmeaParseGPRMC(argc, argv, (nmeaGPRMC*) q);
                    if (i < 0) { nmeaPrintError(i); }
                    else {
                        nmeaGPRMCInfo((nmeaGPRMC*) q, i);
                        nmeaInfoPosTime(i);
                    }
                }
                else if (strcmp_P(argv[0], PSTR("GPVTG")) == 0) {
                    i = nmeaParseGPVTG(argc, argv, (nmeaGPVTG*) q);
                    if (i < 0) { nmeaPrintError(i); }
                    else {
                        nmeaGPVTGInfo((nmeaGPVTG*) q, i);
                    }
                }
                else if (strcmp_P(argv[0], PSTR("GPZDA")) == 0) {
                    i = nmeaParseGPZDA(argc, argv, (nmeaTIME*) q);
                    if (i < 0) { nmeaPrintError(i); }
                    else {
                        nmeaInfoSetTime((nmeaTIME*) q, i);
                        nmeaInfoPosTime(i);
                    }
                }
            }
        }
    }
}
