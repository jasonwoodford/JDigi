
#include "lcdshield_avr.h"

static uint8_t const lcdshieldCGRam[8][8] PROGMEM = {
    { 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000 },
    { 0b11000, 0b11000, 0b11000, 0b11000, 0b11000, 0b11000, 0b11000, 0b11000 },
    { 0b11100, 0b11100, 0b11100, 0b11100, 0b11100, 0b11100, 0b11100, 0b11100 },
    { 0b11110, 0b11110, 0b11110, 0b11110, 0b11110, 0b11110, 0b11110, 0b11110 },
    { 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111 },
    { 0b00000, 0b00000, 0b00000, 0b00000, 0b11111, 0b00100, 0b11111, 0b11111 },
    { 0b00000, 0b00000, 0b11111, 0b00100, 0b11111, 0b11111, 0b11111, 0b11111 },
    { 0b11111, 0b00100, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111 }
};

extern APRSConfig config;
extern LCD lcd;

/** Initialize the LCD controller.
 *
 * The initialization sequence has a mandatory timing so the
 * controller can safely recognize the type of interface desired.
 */
void lcdshieldInit (void) {
    uint8_t i, j;
    
    // Initialize the ports/pins required for read only LCD.
    LCDSHIELD_D4_DDR |= (uint8_t) (1 << LCDSHIELD_D4_PIN);
    LCDSHIELD_D5_DDR |= (uint8_t) (1 << LCDSHIELD_D5_PIN);
    LCDSHIELD_D6_DDR |= (uint8_t) (1 << LCDSHIELD_D6_PIN);
    LCDSHIELD_D7_DDR |= (uint8_t) (1 << LCDSHIELD_D7_PIN);
    LCDSHIELD_RS_DDR |= (uint8_t) (1 << LCDSHIELD_RS_PIN);
    LCDSHIELD_E_DDR |= (uint8_t) (1 << LCDSHIELD_E_PIN);
    // Initialize the backlight control.
    LCDSHIELD_BL_DDR |= (uint8_t) (1 << LCDSHIELD_BL_PIN);
    // 40 ms needed for Vcc = 2.7 V
    _delay_ms(40);
    // 4-bit init sequence
    lcdshieldOutnibble(0x03, 0);
    _delay_ms(5);
    lcdshieldOutnibble(0x03, 0);
    _delay_us(160);
    lcdshieldOutnibble(0x03, 0);
    _delay_us(160);
    lcdshieldOutnibble(0x02, 0);
    _delay_us(160);
    lcdshieldOutcmd(HD44780_FUNCSET | HD44780_FUNCSET_2LINE);
    lcdshieldOutcmd(HD44780_DISPCTRL | HD44780_DISPCTRL_ON | HD44780_DISPCTRL_BLINK);
    lcdshieldOutcmd(HD44780_ENTRYMODE | HD44780_ENTRYMODE_INC);
    // Program the CGRAM character definitions.
    for (i = 0; i < 8; ++i) {
        for (j = 0; j < 8; ++j) {
            lcdshieldOutcmd(HD44780_CGADDR((i << 3) | j));
            lcdshieldOutdata(pgm_read_byte(&lcdshieldCGRam[i][j]));
        }
    }
    // Backlight.
    lcdshieldBacklightSet(config.lcdMode & LCD_FLAGS_BACKLIGHT);
}

/** Write one nibble (4-bits).
 */
void lcdshieldOutnibble (uint8_t n, uint8_t rs) {
    register uint8_t i;
    //
    i = LCDSHIELD_D4_PORT;
    if (n & 1) {
        i |= (uint8_t) (1 << LCDSHIELD_D4_PIN);
    } else {
        i &= (uint8_t) ~(1 << LCDSHIELD_D4_PIN);
    }
    LCDSHIELD_D4_PORT = i;
    //
    i = LCDSHIELD_D5_PORT;
    if (n & 2) {
        i |= (uint8_t) (1 << LCDSHIELD_D5_PIN);
    } else {
        i &= (uint8_t) ~(1 << LCDSHIELD_D5_PIN);
    }
    LCDSHIELD_D5_PORT = i;
    //
    i = LCDSHIELD_D6_PORT;
    if (n & 4) {
        i |= (uint8_t) (1 << LCDSHIELD_D6_PIN);
    } else {
        i &= (uint8_t) ~(1 << LCDSHIELD_D6_PIN);
    }
    if (n & 8) {
        i |= (uint8_t) (1 << LCDSHIELD_D7_PIN);
    } else {
        i &= (uint8_t) ~(1 << LCDSHIELD_D7_PIN);
    }
    if (rs == 1) {
        i |= (uint8_t) (1 << LCDSHIELD_RS_PIN);
    } else {
        i &= (uint8_t) ~(1 << LCDSHIELD_RS_PIN);
    }
    LCDSHIELD_D6_PORT = i;
    //
    _delay_us(1);
    LCDSHIELD_E_PORT |= (uint8_t) (1 << LCDSHIELD_E_PIN);
    _delay_us(1);
    LCDSHIELD_E_PORT &= (uint8_t) ~(1 << LCDSHIELD_E_PIN);
}

/** Send byte to the LCD.
 * 
 * Write one byte 4-bits wide twice. rs is the register select:
 * 0 selects instruction register, 1 selects the data register.
 */
void lcdshieldOutbyte (uint8_t b, uint8_t rs) {
    while (atomMutexGet(&lcd.mutex, 0) != ATOM_OK) atomTimerDelay(1);
    lcdshieldOutnibble((b >> 4) & 0x0F, rs);
    lcdshieldOutnibble(b & 0x0F, rs);
    atomMutexPut(&lcd.mutex);
    _delay_us(41);
}

/** Backlight control.
 * 
 * If (state > 0) turn backlight on, else turn it off.
 */
void lcdshieldBacklightSet (uint8_t state) {
    if (state > 0) {
        lcd.flags |= LCD_FLAGS_BACKLIGHT;
        LCDSHIELD_BL_PORT |= (uint8_t) (1 << LCDSHIELD_BL_PIN);
    } else {
        lcd.flags &= (uint8_t) ~LCD_FLAGS_BACKLIGHT;
        LCDSHIELD_BL_PORT &= (uint8_t) ~(1 << LCDSHIELD_BL_PIN);
    }
}
