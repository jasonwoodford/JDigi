/*
 * jdigi-eeprom.h
 * 
 * Copyright (C)2016 Jason Woodford. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: jdigi-eeprom.h,v 0.9a 2016/12/20 20:40:00 NDT jason_woodford Exp $
 */
#ifndef __JDIGI_EEPROM_H_
#define __JDIGI_EEPROM_H_

/* Default EEPROM configuration data. */
APRSConfig configEE EEMEM = {
    .srcCall = "VO1JWW",
    .srcSSID = 2,
    .destCall = "APRJ09",
    .destSSID = 0,
    .viaCall1 = "\0",
    .viaSSID1 = 0,
    .viaCall2 = "\0",
    .viaSSID2 = 0,
    .chainFlags = 0,
    .txIntPos = 2400,   // seconds
    .txIntWX = 3600,
    .txIntBeacon = 2400,
    .txOffPos = 15,
    .txOffWX = 45,
    .txOffBeacon = 75,
    .posLatD = +48,     // signed degrees
    .posLatM = 55.20f,  // decimal minutes
    .posLongD = -55,    // signed degrees
    .posLongM = 40.20f, // decimal minutes
    .icon1 = '/',
    .icon2 = '*',
    .uart0Baud = 9600,  // BPS
    .uart1Baud = 9600,
    .lcdMode = LCD_FLAGS_MODE_CLK,
    .debugFlags = 0,
    .crc0 = 0x0000,     // intentionally invalid
    .crc1 = 0x0000,     // intentionally invalid
    .utcOffset = (-7 * (ONE_HOUR / 2)), // NST.
    .lastTime = 587583750,
    .infoComment = "JDigi v.0.99-prerelease"
};

#endif /* __JDIGI_EEPROM_H_ */
