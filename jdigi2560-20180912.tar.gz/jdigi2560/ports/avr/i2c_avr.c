/*
 * i2c_avr.c
 * 
 * Copyright (c) 2018, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: i2c_avr.c,v 0.9a 2018/08/06 21:39:00 NDT jason_woodford Exp $
 */

#include "i2c_avr.h"

/** Initialize the I2C bus.
 */
void i2cInit (void) {
    // Enable TWI by writing a zero to the power reduction register bit.
    PRR0 &= (uint8_t) ~_BV(PRTWI);
    // Set prescaler. (1, 4, 16, or 64)
    TWSR = (uint8_t) (I2C_PRESCALER & 0x03);
    // Set bitrate of bus.
    TWBR = (uint8_t) (((AVR_CPU_HZ / I2C_BITRATE) - 16) / (2 * (1 << (2 * I2C_PRESCALER))));
    // Enable!
    TWCR = _BV(TWEN);
}

/** Wait for an I2C response.
 *  Returns the I2C status.
 */
uint8_t i2cWait (void) {
    uint8_t timeout;
    // Wait for a number of system ticks (typ. 200 ms.)
    timeout = I2C_WAIT_TICKS;
    while (timeout-- > 0) {
        if (TWCR & _BV(TWINT)) break;
        atomTimerDelay(1);
    }
    return TW_STATUS;
}

/** Send a START.
 */
uint8_t i2cStart (void) {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);
    return i2cWait();
}

/** Send a STOP.
 */
void i2cStop (void) {
    TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);
}

/** Write one byte from data.
 */
uint8_t i2cWrite (uint8_t data) {
    TWDR = data;
    TWCR = _BV(TWINT) | _BV(TWEN);
    return i2cWait();
}

/** Read one byte into *data. Send an ACK if ack is 1.
 */
uint8_t i2cRead (uint8_t *data, uint8_t ack) {
    uint8_t stat;
    // Read data with ACK/NACK.
    if (ack) {
        TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWEA);
    } else {
        TWCR = _BV(TWINT) | _BV(TWEN);
    }
    stat = i2cWait();
    *data = TWDR;
    return stat;
}
