/*
 * onewire_avr.c
 * 
 * Copyright (c) 2017, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: onewire_avr.c,v 0.9a 2017/05/01 21:39:00 NDT jason_woodford Exp $
 */

#include "onewire_avr.h"

extern ONEWIRE      onewire;
extern ONEWIREDev   onewireDevice[ONEWIRE_MAX_DEV];

/** Initialize the OneWire(tm) bus port and structures.
 */
void onewireInit (void) {
    int8_t i;
    
    ONEWIRE_DATA_DDR &= ~_BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    onewire.devcount = 0;
    onewire.flags = 0;
    for (i = 0; i < ONEWIRE_MAX_DEV; ++i) onewireDevice[i].flags = 0;
}

/** Send a reset pulse and wait for a presence pulse.
 * 
 * Returns zero if device found, or an error value. 
 */
int8_t onewireReset (void) {
    int8_t val;
    uint16_t timeout;
    CRITICAL_STORE;
    //
    val = 0;
    // Check bus for a high level before starting.
    if (!(ONEWIRE_DATA_READ & _BV(ONEWIRE_DATA_PIN))) return ONEWIRE_ERROR_BUS;
    // Disable interrupts!
    CRITICAL_START();
    // Set data pin as output and set low.
    ONEWIRE_DATA_DDR |= _BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    _delay_us(ONEWIRE_RESET_TIME);
    // Set data high, as input, no pull-up.
    ONEWIRE_DATA_PORT |= _BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_DDR &= ~_BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    // Wait for data to be pulled low, then high again.
    timeout = ONEWIRE_PRESENCE_TIME;
    while (ONEWIRE_DATA_READ & _BV(ONEWIRE_DATA_PIN)) {
        if (timeout == 0) {
            val = ONEWIRE_ERROR_NORESP;
            break;
        }
        --timeout;
        _delay_us(1);
    }
    while ((!(ONEWIRE_DATA_READ & _BV(ONEWIRE_DATA_PIN))) && (val == 0)) {
        if (timeout == 0) {
            val = ONEWIRE_ERROR_RESP;
            break;
        }
        --timeout;
        _delay_us(1);
    }
    if (timeout > 0) {
        --timeout;
        _delay_us(1);
    }
    // Re-enable interrupts!
    CRITICAL_END();
    return val;
}

/** Writes a logic 0 or 1 to the OneWire bus.
 */
void onewireWrite (uint8_t val) {
    CRITICAL_STORE;
    
    CRITICAL_START();
    // Set data pin as low output.
    ONEWIRE_DATA_DDR |= _BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    _delay_us(ONEWIRE_RW_PULSETIME);
    // Set data pin as input with no pull-up early if logic 1.
    if (val > 0) {
        ONEWIRE_DATA_DDR &= ~_BV(ONEWIRE_DATA_PIN);
        ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    }
    _delay_us(ONEWIRE_RW_HOLDTIME);
    // Set data pin as input, no pull-up.
    ONEWIRE_DATA_DDR &= ~_BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    _delay_us(ONEWIRE_RW_RECTIME);
    CRITICAL_END();
}

/** Reads a bit from the OneWire bus.
 * 
 * Returns 1 or 0.
 */
uint8_t onewireRead (void) {
    uint8_t val;
    CRITICAL_STORE;
    
    val = 0;
    CRITICAL_START();
    // Send read pulse.
    ONEWIRE_DATA_DDR |= _BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    _delay_us(ONEWIRE_RW_PULSETIME);
    // Set data pin as input, no pull-up.
    ONEWIRE_DATA_DDR &= ~_BV(ONEWIRE_DATA_PIN);
    ONEWIRE_DATA_PORT &= ~_BV(ONEWIRE_DATA_PIN);
    _delay_us(ONEWIRE_RW_SAMPLETIME);
    // Read data pin.
    if (ONEWIRE_DATA_READ & _BV(ONEWIRE_DATA_PIN)) val = 1;
    _delay_us(ONEWIRE_RW_HOLDTIME);
    CRITICAL_END();
    return val;
}
