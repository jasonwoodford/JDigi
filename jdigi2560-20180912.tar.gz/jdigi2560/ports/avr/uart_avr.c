/*
 * uart.c
 * 
 * UART implementation for the ATMega2560 that utilizes interrupt-driven RX
 * and TX routines.
 * 
 * Copyright (C)2016 Jason Woodford. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: uart.c,v 0.9a 2016/09/25 15:45:00 NDT jason_woodford Exp $
 */

#include "uart_avr.h"

FILE fstrUart0 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);
FILE fstrUart1 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);
FILE fstrUart2 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);
FILE fstrUart3 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);

extern UART uart[UART_PORTS];

/** Perform UART startup initialization.
 * 
 * Sets requested baudrate, tx/rx, 8N1.
 * Also sets the rx and tx buffer indexes.
 */
int8_t uartInit (uint8_t port, uint32_t baudrate) {
    uint16_t ubbr;
    uint8_t ubbrh;
    uint8_t ubbrl;
    
    // Is the port value valid?
    if (port >= UART_PORTS) return UART_ERROR_PORT;
    // Create a mutex for single-threaded putchar() access.
    if (atomMutexCreate(&(uart[port].mutex)) != ATOM_OK) return UART_ERROR_MUTEX;
    // ATmega datasheets list 2400 baud as the lowest example rate.
    if (baudrate < 2400) return UART_ERROR_BAUD;
    // Setup buffer indexes before enabling the UART.
    uart[port].rxHead = 0;
    uart[port].rxTail = 0;
    uart[port].txHead = 0;
    uart[port].txTail = 0;
    uart[port].flags = 0;
        
    // Set up the UART device with the selected baudrate and enable with interrupts.
    ubbr = (AVR_CPU_HZ + baudrate * 8L) / (baudrate * 16L) - 1; // GNU AVR lib spec.
    ubbrh = (ubbr >> 8) & 0x0F;
    ubbrl = ubbr & 0xFF;
    switch (port) {
        case 0:
            UBRR0H = ubbrh;
            UBRR0L = ubbrl;
            UCSR0B = _BV(RXEN0) | _BV(TXEN0) | _BV(RXCIE0);
            break;
        case 1:
            UBRR1H = ubbrh;
            UBRR1L = ubbrl;
            UCSR1B = _BV(RXEN1) | _BV(TXEN1) | _BV(RXCIE1);
            break;
        case 2:
            UBRR2H = ubbrh;
            UBRR2L = ubbrl;
            UCSR2B = _BV(RXEN2) | _BV(TXEN2) | _BV(RXCIE2);
            break;
        case 3:
            UBRR3H = ubbrh;
            UBRR3L = ubbrl;
            UCSR3B = _BV(RXEN3) | _BV(TXEN3) | _BV(RXCIE3);
            break;
    }
    return 0;
}

/** C-style putchar() used by stdio, which utilizes a FIFO buffer.
 *
 * __This function will block if the buffer is full.__
 */
int uartPutchar (uint8_t c, FILE *stream) {
    uint8_t port;
    
    if (stream == &fstrUart0) {
        port = 0;
    }
    else if (stream == &fstrUart1) {
        port = 1;
    }
    else if (stream == &fstrUart2) {
        port = 2;
    }
    else if (stream == &fstrUart3) {
        port = 3;
    }
    else {
        return _FDEV_ERR;
    }
    
    // Block on private access to the UART
    while (atomMutexGet(&(uart[port].mutex), 10) != ATOM_OK) atomTimerDelay(1);
    // can we put data in the buffer?
    while (uart[port].flags & UART_FLAG_TXFULL) atomTimerDelay(1);
    // put a new char in the buffer.
    uart[port].txBuffer[uart[port].txHead] = c;
    ++uart[port].txHead;
    if (uart[port].txHead == UART_TX_BUFSIZE) uart[port].txHead = 0;
    // if the head equals the tail at this point, then the buffer is full.
    if (uart[port].txHead == uart[port].txTail) uart[port].flags |= UART_FLAG_TXFULL;
    // finally, we have data to transmit.
    uart[port].flags |= UART_FLAG_TXDATA;
    // Return mutex access
    atomMutexPut(&(uart[port].mutex));
    // enable interrupt.
    switch (port) {
        case 0:
            UCSR0B |= _BV(UDRIE0);
            break;
        case 1:
            UCSR1B |= _BV(UDRIE1);
            break;
        case 2:
            UCSR2B |= _BV(UDRIE2);
            break;
        case 3:
            UCSR3B |= _BV(UDRIE3);
            break;  
    }
    return 0;
}

/** C-style getchar() used by stdio, which utilizes a FIFO buffer.
 * 
 * Input errors while talking to the UART will cause an immediate
 * return of -1 (error indication).  Notably, this will be caused by a
 * framing error (e. g. serial line "break" condition), by an input
 * overrun, and by a parity error (if parity was enabled and automatic
 * parity recognition is supported by hardware).
 *
 * __This function will block if there is no data.__
 */
int uartGetchar (FILE *stream) {
    int c;
    uint8_t port;
    //
    if (stream == &fstrUart3) {
        port = 3;
    }
    else if (stream == &fstrUart2) {
        port = 2;
    }
    else if (stream == &fstrUart1) {
        port = 1;
    }
    else if (stream == &fstrUart0) {
        port = 0;
    }
    else {
        return _FDEV_ERR;
    }
    // Block until there is new data.
    while (!(uart[port].flags & UART_FLAG_RXDATA)) atomTimerDelay(1);
    // Get private access to the UART.
    while (atomMutexGet(&(uart[port].mutex), 10) != ATOM_OK) atomTimerDelay(1);
    // get the char now and update index and flags.
    c = uart[port].rxBuffer[uart[port].rxTail++];
    if (uart[port].rxTail == UART_RX_BUFSIZE) uart[port].rxTail = 0;
    uart[port].flags &= ~UART_FLAG_RXFULL;
    if (uart[port].rxTail == uart[port].rxHead) uart[port].flags &= ~UART_FLAG_RXDATA;
    // check other flags. All must be reset.
    if (uart[port].flags & UART_FLAG_FRAMEERR) {
        uart[port].flags &= ~UART_FLAG_FRAMEERR;
        c = _FDEV_ERR;
    }
    if (uart[port].flags & UART_FLAG_PARITYERR) {
        uart[port].flags &= ~UART_FLAG_PARITYERR;
        c = _FDEV_ERR;
    }
    if (uart[port].flags & UART_FLAG_RXOVERRUN) {
        uart[port].flags &= ~UART_FLAG_RXOVERRUN;
        c = _FDEV_ERR;
    }
    // Return mutex access.
    atomMutexPut(&(uart[port].mutex));
    return c;
}

/** Receive data Interrupt Service Routines.
 * 
 */
ISR(USART0_RX_vect) {
    atomIntEnter();
    // Check the RX error bits.
    if (UCSR0A & _BV(FE0)) uart[0].flags |= UART_FLAG_FRAMEERR;
    if (UCSR0A & _BV(PE0)) uart[0].flags |= UART_FLAG_PARITYERR;
    if (UCSR0A & _BV(DOR0)) uart[0].flags |= UART_FLAG_RXOVERRUN;
    // Grab the byte now. This forces the interrupt flag to clear.
    uart[0].rxChar = UDR0;
    // Is the RX buffer full?
    if (uart[0].flags & UART_FLAG_RXFULL) {
        // Set the overrun flag, can do no more.
        uart[0].flags |= UART_FLAG_RXOVERRUN;
    } else {
        // Place byte in buffer.
        uart[0].rxBuffer[uart[0].rxHead] = uart[0].rxChar;
        ++uart[0].rxHead;
        if (uart[0].rxHead == UART_RX_BUFSIZE) uart[0].rxHead = 0;
        // If the buffer is full, set flag.
        if (uart[0].rxHead == uart[0].rxTail) uart[0].flags |= UART_FLAG_RXFULL;
        // We have new data
        uart[0].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

ISR(USART1_RX_vect) {
    atomIntEnter();
    if (UCSR1A & _BV(FE1)) uart[1].flags |= UART_FLAG_FRAMEERR;
    if (UCSR1A & _BV(PE1)) uart[1].flags |= UART_FLAG_PARITYERR;
    if (UCSR1A & _BV(DOR1)) uart[1].flags |= UART_FLAG_RXOVERRUN;
    uart[1].rxChar = UDR1;
    if (uart[1].flags & UART_FLAG_RXFULL) {
        uart[1].flags |= UART_FLAG_RXOVERRUN;
    } else {
        uart[1].rxBuffer[uart[1].rxHead++] = uart[1].rxChar;
        if (uart[1].rxHead == UART_RX_BUFSIZE) uart[1].rxHead = 0;
        if (uart[1].rxHead == uart[1].rxTail) uart[1].flags |= UART_FLAG_RXFULL;
        uart[1].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

ISR(USART2_RX_vect) {
    atomIntEnter();
    if (UCSR2A & _BV(FE2)) uart[2].flags |= UART_FLAG_FRAMEERR;
    if (UCSR2A & _BV(PE2)) uart[2].flags |= UART_FLAG_PARITYERR;
    if (UCSR2A & _BV(DOR2)) uart[2].flags |= UART_FLAG_RXOVERRUN;
    uart[2].rxChar = UDR2;
    if (uart[2].flags & UART_FLAG_RXFULL) {
        uart[2].flags |= UART_FLAG_RXOVERRUN;
    } else {
        uart[2].rxBuffer[uart[2].rxHead++] = uart[2].rxChar;
        if (uart[2].rxHead == UART_RX_BUFSIZE) uart[2].rxHead = 0;
        if (uart[2].rxHead == uart[2].rxTail) uart[2].flags |= UART_FLAG_RXFULL;
        uart[2].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

ISR(USART3_RX_vect) {
    atomIntEnter();
    if (UCSR3A & _BV(FE3)) uart[3].flags |= UART_FLAG_FRAMEERR;
    if (UCSR3A & _BV(PE3)) uart[3].flags |= UART_FLAG_PARITYERR;
    if (UCSR3A & _BV(DOR3)) uart[3].flags |= UART_FLAG_RXOVERRUN;
    uart[3].rxChar = UDR3;
    if (uart[3].flags & UART_FLAG_RXFULL) {
        uart[3].flags |= UART_FLAG_RXOVERRUN;
    } else {
        uart[3].rxBuffer[uart[3].rxHead++] = uart[3].rxChar;
        if (uart[3].rxHead == UART_RX_BUFSIZE) uart[3].rxHead = 0;
        if (uart[3].rxHead == uart[3].rxTail) uart[3].flags |= UART_FLAG_RXFULL;
        uart[3].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

/** Transmit Ready Interrupt Service Routines.
 * 
 */
ISR(USART0_UDRE_vect) {
    atomIntEnter();
    // Do we have another byte to TX?
    if (uart[0].flags & UART_FLAG_TXDATA) {
        UDR0 = uart[0].txBuffer[uart[0].txTail++];
        if (uart[0].txTail == UART_TX_BUFSIZE) uart[0].txTail = 0;
        uart[0].flags &= ~UART_FLAG_TXFULL;
        // Is this the last byte?
        if (uart[0].txTail == uart[0].txHead) {
            uart[0].flags &= ~UART_FLAG_TXDATA;
            // Disable interrupt.
            UCSR0B &= ~_BV(UDRIE0);
        }
    }
    atomIntExit(FALSE);
}

ISR(USART1_UDRE_vect) {
    atomIntEnter();
    if (uart[1].flags & UART_FLAG_TXDATA) {
        UDR1 = uart[1].txBuffer[uart[1].txTail++];
        if (uart[1].txTail == UART_TX_BUFSIZE) uart[1].txTail = 0;
        uart[1].flags &= ~UART_FLAG_TXFULL;
        if (uart[1].txTail == uart[1].txHead) {
            uart[1].flags &= ~UART_FLAG_TXDATA;
            UCSR1B &= ~_BV(UDRIE1);
        }
    }
    atomIntExit(FALSE);
}

ISR(USART2_UDRE_vect) {
    atomIntEnter();
    if (uart[2].flags & UART_FLAG_TXDATA) {
        UDR2 = uart[2].txBuffer[uart[2].txTail++];
        if (uart[2].txTail == UART_TX_BUFSIZE) uart[2].txTail = 0;
        uart[2].flags &= ~UART_FLAG_TXFULL;
        if (uart[2].txTail == uart[2].txHead) {
            uart[2].flags &= ~UART_FLAG_TXDATA;
            UCSR2B &= ~_BV(UDRIE2);
        }
    }
    atomIntExit(FALSE);
}

ISR(USART3_UDRE_vect) {
    atomIntEnter();
    if (uart[3].flags & UART_FLAG_TXDATA) {
        UDR3 = uart[3].txBuffer[uart[3].txTail++];
        if (uart[3].txTail == UART_TX_BUFSIZE) uart[3].txTail = 0;
        uart[3].flags &= ~UART_FLAG_TXFULL;
        if (uart[3].txTail == uart[3].txHead) {
            uart[3].flags &= ~UART_FLAG_TXDATA;
            UCSR3B &= ~_BV(UDRIE3);
        }
    }
    atomIntExit(FALSE);
}
