/*
 * threadShell.c
 * 
 * Copyright (c) 2018, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * The main() function is derived from tests-main.c,
 * part of Atomthreads (c) 2010, Kelvin Lawson.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: threadShell.c,v 0.9a 2018/08/20 21:46:00 NDT jason_woodford Exp $
 */

#include "threads.h"
#include "command-extern.h" // Program memory string pointers.

static uint8_t  bufShell[SHELL_STATIC_SIZE];    ///< USB Shell static buffer.

/** USB Shell thread.
 * 
 */
void threadShell (uint32_t data) {
    uint8_t flag;
    uint8_t size;
    uint8_t argc;
    char    *argv[8];
    char    *p, *q;
    int     c;
    //
    p = (char*) bufShell;
    while (TRUE) {
        flag = FALSE;
        size = 0;
        fputs_P(pstrCmdPROMPT, stdout);
        //// Capture command line input.
        //
        while (!flag) {
            c = fgetc(stdin);
            switch (c) {
                case _FDEV_EOF:
                    // do nothing.
                    size = 0;
                    break;
                case _FDEV_ERR:
                    // bad RX.
                    fputs_P(PSTR("\n*Receive Error*\n"), stdout);
                    size = 0;
                    break;
                case '\n':
                    // ignore any newlines.
                    break;
                case '\b':
                    // treat the backspace char.
                    if (size > 0) {
                        fputs_P(PSTR("\b \b"), stdout);
                        --size;
                    }
                    break;
                case '\r':
                    // a CR signifies end of command.
                    *(p + size) = 0;
                    fputc('\n', stdout);    // echo a newline.
                    flag = TRUE;
                    break;
                default:
                    *(p + size) = (char) c;
                    fputc(c, stdout);       // echo the char.
                    ++size;
            }
            if (size == COMMAND_LINESIZE) {
                fputs_P(PSTR("\n*Command Buffer Overflow*\n"), stdout);
                size = 0;
            }
        }
        //// Parse command line.
        //
        argc = cmdParseLine(p, size, argv);
        // If there are no args skip the command interpreter.
        if (argc == 0) continue;
        //// Command interpreter.
        //
        strupr(argv[0]);
        q = p + size;
        if (strcmp_P(argv[0], pstrCmdBeaconList) == 0) {
            cmdBeaconList(q);
        } else if (strcmp_P(argv[0], pstrCmdBeaconClear) == 0) {
            cmdBeaconClear(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdBeaconSet) == 0) {
            cmdBeaconSet(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetClock) == 0) {
            cmdClockSet(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetCall) == 0) {
            cmdConfigSetcall(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetDest) == 0) {
            cmdConfigSetdest(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetVia1) == 0) {
            cmdConfigSetvia1(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetVia2) == 0) {
            cmdConfigSetvia2(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetPos) == 0) {
            cmdConfigSetpos(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetIcon) == 0) {
            cmdConfigSeticon(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetComment) == 0) {
            cmdConfigSetcomment(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetPosint) == 0) {
            cmdConfigSetposint(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetWXint) == 0) {
            cmdConfigSetwxint(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetBeaconint) == 0) {
            cmdConfigSetbeaconint(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdSetChainflags) == 0) {
            cmdConfigSetchainflags(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdWriteEeprom) == 0) {
            cmdConfigWriteEeprom(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdLcdInit) == 0) {
            cmdLcdInit(q, argc, argv);
        } else if (strcmp_P(argv[0], pstrCmdHelp) == 0) {
            cmdPrintHelp(q, argc, argv);
        } else {
            strcpy_P(q, PSTR("?Unknown command"));
        }
        // Send output.
        fputs(q, stdout);
    }
}
