/*
 * threadEnviro.c
 * 
 * Copyright (c) 2018, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * The main() function is derived from tests-main.c,
 * part of Atomthreads (c) 2010, Kelvin Lawson.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: threadEnviro.c,v 0.9a 2018/08/20 21:46:00 NDT jason_woodford Exp $
 */

#include "threads.h"

//extern BME280   enviroBME280;

/** Environmental update thread.
 * 
 */
void threadEnviro (uint32_t data) {
    int8_t  count;
    //uint8_t stat;
    char    devid[11];
    //
    count = 0;
    strcpy_P(devid, PSTR("18B20_00"));
    while (TRUE) {
        // Environmental stuff is sampled ~ 5 sec.
        atomTimerDelay(5 * SYSTEM_TICKS_PER_SEC);
        ds18b20GetTemp(devid);
        if (++count == 2) {
            // Debug stuff goes here.
            count = 0;
            // TEST BME280
            //stat = bme280ReadEnviro(BME280_I2C_ADDRESS);
            //if (stat > 0) fprintf_P(stderr, PSTR("\nBME280 Read Status: 0x%02X"), stat);
            // Always do a bme280CompTemp() before other functions.
            //fprintf_P(stderr, PSTR("\nBME280:[T/P/H]:[%f / "), bme280CompTemp());
            //fprintf_P(stderr, PSTR("%f / %f]"), bme280CompPres(), bme280CompHumd());
            // TEST DHT11
            //i = dht11Read();
            //fprintf_P(stderr, PSTR("\nDHT11[T/H]:%02d/%02d(%d)"), dht11.temp, dht11.humd, i);
        }
    }
}
