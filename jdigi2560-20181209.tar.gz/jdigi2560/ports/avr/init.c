/*
 * init.c
 * 
 * Copyright (c) 2017, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: init.c,v 0.9a 2017/03/27 21:46:00 NDT jason_woodford Exp $
 */

#include "init.h"

extern FILE fstrLcd;
extern FILE fstrNULL;
extern FILE fstrUart0;
extern LED  led;
extern DS18B20  ds18b20[];
extern APRSConfig   config;                   ///< Global configuration data.
extern APRSConfig   configEE EEMEM;           ///< EEPROM configuration data.
extern APRSConfig   const configJD PROGMEM;   ///< Default configuration data.
extern APRSPosit    position;

/** Initialize system variables and hardware after atomOSStart().
 */
void sysInit (char *buf) {
	uint8_t  i;
    uint8_t  confsrc;
    uint8_t  *p, *q;
    uint16_t crc[2];
    //time_t   timer;
    // Load EEPROM configuration.
    p = (uint8_t*) &configEE;
	q = (uint8_t*) &config;
    confsrc = TRUE;
    for (i = 0; i < APRS_CONFIG_TOTAL_SIZE; ++i) *q++ = eeprom_read_byte(p++);
    // Check CRCs and use default/progmem config if either are invalid.
    crc[0] = crcCalc_16((uint8_t*) &config, APRS_CONFIG_BASE_SIZE);
    crc[1] = crcCalc_16((uint8_t*) config.infoComment, strlen(config.infoComment));
    if ((crc[0] != config.crc0) || (crc[1] != config.crc1)) {
        confsrc = FALSE;
        memcpy_P(&config, &configJD, APRS_CONFIG_TOTAL_SIZE);
    }
    // Set the DST function and clock time.
    set_zone(config.utcOffset);
    set_dst(usa_dst);
    set_system_time(config.lastTime);
    // Set the local position, etc.
    position.latitudeD = config.posLatD;
    position.latitudeM = config.posLatM;
    position.longitudeD = config.posLongD;
    position.longitudeM = config.posLongM;
    position.icon1 = config.icon1;
    position.icon2 = config.icon2;
    // Call core initialization functions.
    ax25InitQueue();
    beaconInit();
    bitbucketInit();
    ledInit(SYSTEM_TICKS_PER_SEC);
    statsInit();
    // Set standard streams to the bitbucket by default.
    stdin = &fstrNULL;
    stdout = &fstrNULL;
    stderr = &fstrNULL;
    // Initialize USB connected UART.
    if (uartInit(0, config.uart0Baud) == 0) {
        stdin = &fstrUart0;
        stdout = &fstrUart0;
        stderr = &fstrUart0;
    }
    // Announce ourselves to the world!
    fputs_P(PSTR(INIT_COPYRIGHT), stderr);
    if (confsrc) {
        fputs_P(PSTR("\nUsing EEPROM configuration."), stderr);
    } else {
        fputs_P(PSTR("\nUsing default configuration."), stderr);
    }
    // What time is it?
    //timer = time(NULL);
    //ctime_r(&timer, buf);
    //fprintf_P(stderr, PSTR("\nCurrent time: %s"), buf);
    // Initialize ADC inputs.
    adcInit();
    // Initialize I2C bus.
    i2cInit();
    // Initialize LCD Shield.
    lcdshieldInit();
    lcdInit();
    // Initialize Menu structure.
    menuInit();
    // Initialize GPS/NMEA structures.
    nmeaInitInfo();
    // Initialize Onewire bus.
    onewireInit();
    // Pre-populate the buffer with a newline.
    *buf = '\n';
    // Perform OneWire device enumeration.
    cmdOnewireEnumerate(buf+1, 0, NULL);
    fputs(buf, stderr);
    // Initialize DS18B20 devices.
    cmdDS18B20Init(buf+1, 0, NULL);
    fputs(buf, stderr);
    // I2C: BME280
    /*
    i = bme280Init(BME280_I2C_ADDRESS);
    if (i > 0) {
        fprintf_P(stderr, PSTR("\nBad BME280 Init! (0x%02X)"), i);
    } else {
        fputs_P(PSTR("\nBME280 device found."), stderr);
    }
    */
    // Additional hardware/sensor initialization.
    //dht11Init();
    // Initialize Radio Modem UART.
    if (uartInit(1, config.uart1Baud) != 0) {
        fputs_P(PSTR("\nCannot initialize radio UART!"), stderr);
    }
    // Initialize GPS UART.
    if (uartInit(2, config.uart2Baud) != 0) {
        fputs_P(PSTR("\nCannot initialize GPS UART!"), stderr);
    }
    // Configure beacons.
    beaconSet(config.txIntPos, config.txOffPos, BEACON_TYPE_POSIT, config.infoComment);
    beaconSet(config.txIntWX, config.txOffWX, BEACON_TYPE_WX, config.infoComment);
    beaconSet(config.txIntBeacon, config.txOffBeacon, BEACON_TYPE_BEACON, config.infoComment);
}
