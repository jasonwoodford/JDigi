/*
 * command.c
 * 
 * Copyright (c) 2017, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: command.c,v 0.9a 2017/06/27 20:46:00 NDT jason_woodford Exp $
 */
#include "command.h"

/* !!! Architecture dependent function prototypes !!! */
void lcdshieldInit (void);

static char const pstrBadParams[]   PROGMEM = "?Bad parameters";
static char const pstrCmdList[]     PROGMEM = \
"Available commands:\n\
LSTBCN  CLRBCN  SETBCN  SETCLK  SETCAL  SETDST  SETVC1  SETVC2\n\
SETPOS  SETICO  SETCOM  SETINP  SETINW  SETINB  SETCFL  WREROM\n\
LCDINI  HELP";

char const pstrCmdPROMPT[]          PROGMEM = "\nJDigi> ";
char const pstrCmdBeaconList[]      PROGMEM = "LSTBCN";
char const pstrCmdBeaconClear[]     PROGMEM = "CLRBCN";
char const pstrCmdBeaconSet[]       PROGMEM = "SETBCN";
char const pstrCmdSetClock[]        PROGMEM = "SETCLK";
char const pstrCmdSetCall[]         PROGMEM = "SETCAL";
char const pstrCmdSetDest[]         PROGMEM = "SETDST";
char const pstrCmdSetVia1[]         PROGMEM = "SETVC1";
char const pstrCmdSetVia2[]         PROGMEM = "SETVC2";
char const pstrCmdSetPos[]          PROGMEM = "SETPOS";
char const pstrCmdSetIcon[]         PROGMEM = "SETICO";
char const pstrCmdSetComment[]      PROGMEM = "SETCOM";
char const pstrCmdSetPosint[]       PROGMEM = "SETINP";
char const pstrCmdSetWXint[]        PROGMEM = "SETINW";
char const pstrCmdSetBeaconint[]    PROGMEM = "SETINB";
char const pstrCmdSetChainflags[]   PROGMEM = "SETCFL";
char const pstrCmdWriteEeprom[]     PROGMEM = "WREROM";
char const pstrCmdLcdInit[]         PROGMEM = "LCDINI";
char const pstrCmdHelp[]            PROGMEM = "HELP";

extern APRSConfig   config;
extern AX25Frame    frame[];
extern Beacon       beacon[];
extern Stats        statTable[];

/** Parse command line.
 */
uint8_t cmdParseLine (char *buf, uint8_t size, char **argv) {
    uint8_t argc;
    uint8_t i;
    char    delim;
    //
    argc = 0;
    i = 0;
    delim = ' ';    
    while (argc < 8) {
        // skip leading spaces and set additional arg values.
        while ((i < size) && (*(buf + i) == ' ')) ++i;
        if (i == size) break;
        // if this arg begins with a " set it as the delimiter.
        if (*(buf + i) == '"') {
            delim = *(buf + i);
            ++i;
        }
        argv[argc] = buf + i;
        ++argc;
        // find the next delimiter and set it to zero.
        while ((i < size) && (*(buf + i) != delim)) ++i;
        *(buf + i) = 0;
        delim = ' ';
        if (i == size) break;
        ++i;
    }
    return argc;
}

/**
 */
char* cmdAPRSHeardDirect (char *buf, uint8_t argc, char **argv) {
    uint8_t i;
    uint8_t j;
    //
    buf += sprintf_P(buf, PSTR("Directs="));
    for (i = 0; i < STATS_SLOTS; ++i) {
        if (!(statTable[i].flags & STATS_FLAG_E)) continue;
        for (j = 0; j < STATS_HOURS; ++j) {
            if (statTable[i].hourlyDirect[j] > 0) {
                *buf++ = ' ';
                buf += ax25FmtAddr(buf, statTable[i].callsign);
                break;
            }
        }
    }
    *buf = 0;
    return buf;
}

/**
 */
char* cmdAPRSHeardAll (char *buf, uint8_t argc, char **argv) {
    uint8_t i;
    //
    buf += sprintf_P(buf, PSTR("Heard="));
    for (i = 0; i < STATS_SLOTS; ++i) {
        if (!(statTable[i].flags & STATS_FLAG_E)) continue;
        *buf++ = ' ';
        buf += ax25FmtAddr(buf, statTable[i].callsign);
    }
    *buf = 0;
    return buf;
}

/**
 */
char* cmdAPRSHeardStatsDirect (char *buf, uint8_t argc, char **argv) {
    uint8_t addr[AX25_ADDR_SIZE];
    uint8_t i;
    uint8_t j;
    //
    if (argc != 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    aprsMakeAddr(argv[1], addr);
    //
    for (j = 0; j < STATS_SLOTS; ++j) {
        if (!(statTable[j].flags & STATS_FLAG_E)) continue;
        if (memcmp(statTable[j].callsign, addr, AX25_ADDR_SIZE) != 0) continue;
        buf += ax25FmtAddr(buf, addr);
        buf += sprintf_P(buf, PSTR(" Heard Direct:"));
        for (i = 0; i < STATS_HOURS; ++i) {
            buf += sprintf_P(buf, PSTR(" %d"), statTable[j].hourlyDirect[i]);
        }
    }
    return buf;
}

/**
 */
char* cmdAPRSHeardStatsAll (char *buf, uint8_t argc, char **argv) {
    uint8_t addr[AX25_ADDR_SIZE];
    uint8_t i;
    uint8_t j;
    //
    if (argc != 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    aprsMakeAddr(argv[1], addr);
    //
    for (j = 0; j < STATS_SLOTS; ++j) {
        if (!(statTable[j].flags & STATS_FLAG_E)) continue;
        if (memcmp(statTable[j].callsign, addr, AX25_ADDR_SIZE) != 0) continue;
        buf += ax25FmtAddr(buf, addr);
        buf += sprintf_P(buf, PSTR(" Heard:"));
        for (i = 0; i < STATS_HOURS; ++i) {
            buf += sprintf_P(buf, PSTR(" %d"), statTable[j].hourlyHeard[i]);
        }
    }
    return buf;
}

/**
 */
char* cmdAPRSRouteTrace (char *buf, uint8_t slot) {
    uint8_t i;
    //
    buf += sprintf_P(buf, PSTR("%s"), config.srcCall);
    if (config.srcSSID > 0) buf += sprintf_P(buf, PSTR("-%d"), config.srcSSID);
    buf += sprintf_P(buf, PSTR(">APRS"));
    for (i = 1; i <= frame[slot].hops; ++i) {
        *buf++ = ',';
        buf += ax25FmtAddr(buf, frame[slot].addr[i+1]);
    }
    *buf++ = ':';
    *buf = 0;
    return buf;
}

/**
 */
char* cmdBeaconList (char *buf) {
    uint8_t i;
    char    *p;
    time_t  timer;
    //
    timer = time(NULL);
    buf += sprintf_P(buf, PSTR("BEACONS:%d"), BEACON_TABLE_SIZE);
    for (i = 0; i < BEACON_TABLE_SIZE; ++i) {
        if (beacon[i].flags & BEACON_FLAG_E) {
            switch (beacon[i].type) {
                case BEACON_TYPE_BEACON:
                    p = (char*) PSTR("BEACON");
                    break;
                case BEACON_TYPE_POSIT:
                    p = (char*) PSTR("POSIT");
                    break;
                case BEACON_TYPE_WX:
                    p = (char*) PSTR("WX");
                    break;
                default:
                    p = (char*) PSTR("UNKNOWN");
            }
            buf += sprintf_P(buf, PSTR(";%d,%S,%d,%d"), i, p, beacon[i].interval, beacon[i].timeout - timer);
        }
    }
    return buf;
}

/**
 */
char* cmdBeaconClear (char *buf, uint8_t argc, char **argv) {
    uint8_t i;
    //
    if (argc != 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    i = atoi(argv[1]);
    if (i >= BEACON_TABLE_SIZE) {
        buf += sprintf_P(buf, PSTR("?Invalid index"));
    } else {
        beacon[i].flags = 0;
        buf += sprintf_P(buf, PSTR("Cleared beacon #%d"), i);
    }
    return buf;
}

/**
 */
char* cmdBeaconSet (char *buf, uint8_t argc, char **argv) {
    uint8_t  type;
    uint16_t period;
    uint16_t offset;
    int8_t   slot;
    //
    if (argc != 4) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    type = argv[1][0];
    period = atoi(argv[2]);
    offset = atoi(argv[3]);
    switch (type) {
        case 'P':
            type = BEACON_TYPE_POSIT;
            break;
        case 'W':
            type = BEACON_TYPE_WX;
            break;
        case 'B':
        default:
            type = BEACON_TYPE_BEACON;
    }
    slot = beaconSet(period, offset, type, config.infoComment);
    if (slot < 0) {
        buf += sprintf_P(buf, PSTR("Beacon could not be set"));
    } else {
        buf += sprintf_P(buf, PSTR("Beacon #%d set"), slot);
    }
    return buf;
}

/**
 */
char* cmdClockSet (char *buf, uint8_t argc, char **argv) {
    uint16_t    tu[3];
    time_t      timer;
    struct tm   clk;
    //
    if (argc != 3) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    // MM/DD/YY
    sscanf_P(argv[1], PSTR("%u/%u/%u"), &tu[0], &tu[1], &tu[2]);
    clk.tm_mon = tu[0] - 1;
    clk.tm_mday = tu[1];
    clk.tm_year = tu[2] - 1900;
    // HH:MM:SS
    sscanf_P(argv[2], PSTR("%u:%u:%u"), &tu[0], &tu[1], &tu[2]);
    clk.tm_hour = tu[0];
    clk.tm_min = tu[1];
    clk.tm_sec = tu[2];
    timer = mktime(&clk);
    set_system_time(timer);
    buf += sprintf_P(buf, PSTR("Time is "));
    ctime_r(&timer, buf);
    buf += strlen(buf);
    // Reset the beacon timeouts.
    beaconReset();
    return buf;
}

/**
 */
char* cmdConfigSetcall (char *buf, uint8_t argc, char **argv) {
    uint8_t ssid;
    int8_t i;
    //
    if (argc != 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    i = aprsParseAddr(argv[1], &ssid);
    if (i > 3) {
        strcpy(config.srcCall, argv[1]);
        config.srcSSID = ssid;
        beaconSet(0, 15, BEACON_TYPE_POSIT, config.infoComment);
        fprintf_P(stderr, PSTR("\nSetCall: %s-%u"), argv[1], ssid);
    } else {
        buf += sprintf_P(buf, PSTR("?Invalid callsign"));
    }
    return buf;
}

/**
 */
char* cmdConfigSetdest (char *buf, uint8_t argc, char **argv) {
    uint8_t ssid;
    int8_t  i;
    //
    if (argc != 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    i = aprsParseAddr(argv[1], &ssid);
    if (i > 3) {
        strcpy(config.destCall, argv[1]);
        config.destSSID = ssid;
        beaconSet(0, 15, BEACON_TYPE_POSIT, config.infoComment);
        buf += sprintf_P(buf, PSTR("SetDest: %s-%u"), argv[1], ssid);
    } else {
        buf += sprintf_P(buf, PSTR("?Invalid callsign"));
    }
    return buf;
}

/**
 */
char* cmdConfigSetvia1 (char *buf, uint8_t argc, char **argv) {
    uint8_t ssid;
    int8_t  i;
    //
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    if (argc == 1) {
        config.viaCall1[0] = 0;
        config.viaSSID1 = 0;
        buf += sprintf_P(buf, PSTR("ClearVia1"));
    } else {
        i = aprsParseAddr(argv[1], &ssid);
        if (i > 3) {
            strcpy(config.viaCall1, argv[1]);
            config.viaSSID1 = ssid;
            buf += sprintf_P(buf, PSTR("SetVia1: %s-%u"), argv[1], ssid);
        } else {
            buf += sprintf_P(buf, PSTR("?Invalid callsign"));
        }
    }
    beaconSet(0, 15, BEACON_TYPE_POSIT, config.infoComment);
    return buf;
}

/**
 */
char* cmdConfigSetvia2 (char *buf, uint8_t argc, char **argv) {
    uint8_t ssid;
    int8_t  i;
    //
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    if (argc == 1) {
        config.viaCall2[0] = 0;
        config.viaSSID2 = 0;
        buf += sprintf_P(buf, PSTR("ClearVia2"));
    } else {
        i = aprsParseAddr(argv[1], &ssid);
        if (i > 3) {
            strcpy(config.viaCall2, argv[1]);
            config.viaSSID2 = ssid;
            buf += sprintf_P(buf, PSTR("SetVia2: %s-%u"), argv[1], ssid);
        } else {
            buf += sprintf_P(buf, PSTR("?Invalid callsign"));
        }
    }
    beaconSet(0, 15, BEACON_TYPE_POSIT, config.infoComment);
    return buf;
}

/**
 */
char* cmdConfigSetpos (char *buf, uint8_t argc, char **argv) {
    uint16_t    tu[2];
    char        tc;
    //
    if (argc != 3) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    sscanf_P(argv[1], PSTR("%u.%u%c"), &tu[0], &tu[1], &tc);
    if ((tu[0] <= 9000) && (tu[1] <= 99) && ((tc == 'N') || (tc == 'S'))) {
        config.posLatD = tu[0] / 100;
        if (tc == 'S') config.posLatD *= -1;
        config.posLatM = (float) (tu[0] % 100);
        config.posLatM = (float) (tu[1] / 100.0f);
    }
    sscanf_P(argv[2], PSTR("%u.%u%c"), &tu[0], &tu[1], &tc);
    if ((tu[0] <= 18000) && (tu[1] <= 99) && ((tc == 'E') || (tc == 'W'))) {
        config.posLongD = tu[0] / 100;
        if (tc == 'W') config.posLongD *= -1;
        config.posLongM = (float) (tu[0] % 100);
        config.posLongM = (float) (tu[1] / 100.0f);
    }
    //
    buf += sprintf_P(buf, PSTR("SetPos: "));
    buf += aprsPrintLat(buf, config.posLatD, config.posLatM, APRS_PRINTFMT_DEGMIN);
    buf += aprsPrintLong(buf, config.posLongD, config.posLongM, APRS_PRINTFMT_DEGMIN);
    return buf;
}

/**
 */
char* cmdConfigSeticon (char *buf, uint8_t argc, char **argv) {
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    // SANITIZE ME!
    config.icon1 = argv[1][0];
    config.icon2 = argv[1][1];
    //
    buf += sprintf_P(buf, PSTR("SetIcon: %c%c"), config.icon1, config.icon2);
    return buf;
}

/**
 */
char* cmdConfigSetcomment (char *buf, uint8_t argc, char **argv) {
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    //
    strncpy(config.infoComment, argv[1], APRS_CONFIG_COMMENT_SIZE);
    buf += sprintf_P(buf, PSTR("SetComment: %s"), config.infoComment);
    return buf;
}

/**
 */
char* cmdConfigSetposint (char *buf, uint8_t argc, char **argv) {
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    //
    config.txIntPos = atoi(argv[1]);
    buf += sprintf_P(buf, PSTR("SetPosInt: %d"), config.txIntPos);
    return buf;
}

/**
 */
char* cmdConfigSetbeaconint (char *buf, uint8_t argc, char **argv) {
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    //
    config.txIntBeacon = atoi(argv[1]);
    buf += sprintf_P(buf, PSTR("SetBeaconInt: %d"), config.txIntBeacon);
    return buf;
}

/**
 */
char* cmdConfigSetwxint (char *buf, uint8_t argc, char **argv) {
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    //
    config.txIntWX = atoi(argv[1]);
    buf += sprintf_P(buf, PSTR("SetWXInt: %d"), config.txIntWX);
    return buf;
}

/**
 */
char* cmdConfigSetchainflags (char *buf, uint8_t argc, char **argv) {
    uint8_t flags;
    //
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    //
    flags = atoi(argv[1]);
    if (flags <= 0xFF) config.chainFlags = flags;
    buf += sprintf_P(buf, PSTR("SetChainFlags: %d"), config.chainFlags);
    return buf;
}

/**
 */
char* cmdConfigWriteEeprom (char *buf, uint8_t argc, char **argv) {
    eepromWriteConfig();
    buf += sprintf_P(buf, PSTR("EEPROM configuration written"), config.chainFlags);
    return buf;
}

/**
 */
char* cmdLcdInit(char *buf, uint8_t argc, char **argv) {
    lcdshieldInit();
    return buf;
}

/**
 */
char* cmdPrintHelp (char *buf, uint8_t argc, char **argv) {
    //
    if (argc > 2) {
        buf += sprintf_P(buf, pstrBadParams);
        return buf;
    }
    if (argc == 2) {
        strupr(argv[1]);
        if (strcmp_P(argv[1], pstrCmdBeaconList) == 0) {
            buf += sprintf_P(buf, PSTR("%s\nLists all active beacons."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdBeaconClear) == 0) {
            buf += sprintf_P(buf, PSTR("%s N\nClears beacon at index N."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdBeaconSet) == 0) {
            buf += sprintf_P(buf, PSTR("%s T I N\nSets beacon.\nT: type (B,P,W); I: interval (secs); N: offset (secs)"), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetClock) == 0) {
            buf += sprintf_P(buf, PSTR("%s M/D/Y H:M:S\nSets system time."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetCall) == 0) {
            buf += sprintf_P(buf, PSTR("%s CALL-SSID\nSets APRS source callsign."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetDest) == 0) {
            buf += sprintf_P(buf, PSTR("%s CALL-SSID\nSets APRS destination callsign."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetVia1) == 0) {
            buf += sprintf_P(buf, PSTR("%s CALL-SSID\nSets APRS via1 path."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetVia2) == 0) {
            buf += sprintf_P(buf, PSTR("%s CALL-SSID\nSets APRS via2 path."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetPos) == 0) {
            buf += sprintf_P(buf, PSTR("%s lat.xxN long.yyE\nSets APRS position."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetIcon) == 0) {
            buf += sprintf_P(buf, PSTR("%s XY\nSets APRS icon."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetComment) == 0) {
            buf += sprintf_P(buf, PSTR("%s \"comment\"\nSets APRS comment."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetPosint) == 0) {
            buf += sprintf_P(buf, PSTR("%s I\nSets APRS Posit interval.\nI: interval (secs)"), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetWXint) == 0) {
            buf += sprintf_P(buf, PSTR("%s I\nSets APRS WX interval.\nI: interval (secs)"), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetBeaconint) == 0) {
            buf += sprintf_P(buf, PSTR("%s I\nSets APRS Beacon interval.\nI: interval (secs)"), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdSetChainflags) == 0) {
            buf += sprintf_P(buf, PSTR("%s X\nSets AX.25 chain flags."), argv[1]);
        } else if (strcmp_P(argv[1], pstrCmdHelp) == 0) {
            buf += sprintf_P(buf, PSTR("...I'm being oppressed!!!"));
        } else {
            buf += sprintf_P(buf, PSTR("%s is not a recognized command."), argv[1]);
        }
    } else {
        buf += sprintf_P(buf, pstrCmdList);
    }
    return buf;
}
