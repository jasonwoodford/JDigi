/*
 * thermistor.c
 * 
 * Copyright (C)2016 Jason Woodford. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: thermistor.c,v 0.9a 2016/10/19 22:25:00 NDT jason_woodford Exp $
 */

#include "thermistor.h"

static uint16_t const thermistorADCTbl[THERMISTOR_COMPTABLE_SIZE] PROGMEM = {
     93, 120, 153, 191, 234, 283, 335, 391, 448, 505, 561, 614, 663, 709,
    749, 786, 818, 846, 870, 891, 909, 925, 938, 950, 959, 968, 975, 981,
    983, 991, 995, 998, 1001};
static int16_t const thermistorDeltaCTbl[THERMISTOR_COMPTABLE_SIZE] PROGMEM = {
    -28, -6, 11, 23, 29, 29, 27, 20, 13, 5, -1, -4, -4, 0, 9, 22, 39, 60,
    86, 114, 146, 180, 216, 254, 294, 335, 377, 421, 468, 510, 555, 601, 648};
static int16_t const thermistorDeltaFTbl[THERMISTOR_COMPTABLE_SIZE] PROGMEM = {
    -32, -10, 7, 19, 25, 25, 23, 16, 9, 1, -5, -8, -8, -4, 5, 18, 35, 56,
    82, 110, 142, 176, 212, 250, 290, 331, 373, 417, 464, 506, 551, 597, 644};

/**
 * 
 */
uint16_t thermistorRead (uint8_t opts) {
    uint16_t val;
    uint8_t index;
    int16_t i, j, k, l;
    //
    val = adcRead(opts);
    for (index = 0; index < THERMISTOR_COMPTABLE_SIZE; index++) {
        // Scan the CompTable for an interval.
        if (val < pgm_read_word(&thermistorADCTbl[index])) break;
    }
    if ((index > 0) && (index < THERMISTOR_COMPTABLE_SIZE)) {
        // Within the comp table.
        i = pgm_read_word(&thermistorADCTbl[index-1]);
        k = pgm_read_word(&thermistorADCTbl[index]) - i;
        if (opts & THERMISTOR_OPT_FAHRENHEIT) {
            // Fahrenheit.
            l = pgm_read_word(&thermistorDeltaFTbl[index-1]);
            j = pgm_read_word(&thermistorDeltaFTbl[index]) - l;
        } else {
            // Celsius.
            l = pgm_read_word(&thermistorDeltaCTbl[index-1]);
            j = pgm_read_word(&thermistorDeltaCTbl[index]) - l;
        }
        return val + (((val - i) * j) / k) + l;
    }
    return val;
}

/** Gets the temperature via thermistorRead() and converts it.
 * 
 * Will convert to either Celcuis or Fahrenheit depending on opt flag.
 * Returns a signed double floating point value.
 */
double thermistorGetTempD (uint8_t opts) {
    if (opts & THERMISTOR_OPT_FAHRENHEIT) {
        // Fahrenheit.
        return ((double) (thermistorRead(opts) - THERMISTOR_CONV_FINT) / THERMISTOR_CONV_FSLOPE);
    } else {
        // Celsius.
        return ((double) (thermistorRead(opts) - THERMISTOR_CONV_CINT) / THERMISTOR_CONV_CSLOPE);
    }
}

/** Gets the temperature via an ADC input.
 *
 * Returns a signed integer value.
 *
int16_t thermistorGetTempI (uint8_t opts) {
    return (int16_t) thermistorGetTempD(opts);
}
 */
