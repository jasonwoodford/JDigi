/*
 * jdigi-pgmstr.h
 * 
 * Copyright (C)2016 Jason Woodford. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: jdigi-pgmstr.h,v 0.9a 2016/10/25 21:30:00 NDT jason_woodford Exp $
 */
#ifndef __JDIGI_PGMSTR_H_
#define __JDIGI_PGMSTR_H_

/* These are fallback system defaults. */
APRSConfig const configJD PROGMEM = {
    .srcCall = "VO1JWW",
    .srcSSID = 2,
    .destCall = "APRJ09",
    .destSSID = 0,
    .viaCall1 = "",
    .viaSSID1 = 1,
    .viaCall2 = "",
    .viaSSID2 = 1,
    .chainFlags = 0,
    .txIntPos = 3600,    // seconds
    .txIntWX = 900,
    .txIntBeacon = 1800,
    .txOffPos = 15,
    .txOffWX = 45,
    .txOffBeacon = 75,
    .posLatD = +48,     // signed degrees
    .posLatM = 55.0f,  // decimal minutes
    .posLongD = -55,    // signed degrees
    .posLongM = 40.0f, // decimal minutes
    .icon1 = '/',
    .icon2 = '*',
    .uart0Baud = 9600,
    .uart1Baud = 9600,
    .lcdMode = LCD_FLAGS_MODE_CLK | LCD_FLAGS_BACKLIGHT,
    .debugFlags = CHAIN_PRINTFRAME_E | CHAIN_PRINTFRAME_VIA | CHAIN_PRINTFRAME_INFO | CHAIN_PRINTFRAME_CRC,
    .repeatFlags = CHAIN_REPEATFLAG_LEGACY | CHAIN_REPEATFLAG_WIDE1 | CHAIN_REPEATFLAG_WIDE2,
    .utcOffset = -7 * (ONE_HOUR / 2), // NST.
    .crc0 = 0,
    .crc1 = 0,
    .lastTime = 588530400,
    .infoComment = "JDigi v.0.99-prerelease"
};

#endif /* __JDIGI_PGMSTR_H_ */
