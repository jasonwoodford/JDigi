/*
 * uart_avr.c
 * 
 * UART implementation for the ATMega2560 that utilizes interrupt-driven RX
 * and TX routines.
 * 
 * Copyright (C)2016 Jason Woodford. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: uart_avr.c,v 1.0 2018/12/18 21:12:00 NST jason_woodford Exp $
 */

#include "uart_avr.h"

FILE fstrUart0 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);
FILE fstrUart1 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);
FILE fstrUart2 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);
FILE fstrUart3 = FDEV_SETUP_STREAM(uartPutchar, uartGetchar, _FDEV_SETUP_RW);

extern UART uart[UART_PORTS];

/** Perform UART configuration.
 * 
 * Sets requested baudrate, tx/rx, 8N1.
 * Also sets the rx and tx buffer indexes and enables interrupts.
 */
void uartConfigurePort (uint8_t port, uint32_t baudrate) {
    uint16_t ubbr;
    uint8_t ubbrh;
    uint8_t ubbrl;
    // Set up the UART device with the selected baudrate and enable interrupts.
    ubbr = (AVR_CPU_HZ + baudrate * 8L) / (baudrate * 16L) - 1; // GNU AVR lib spec.
    ubbrh = (ubbr >> 8) & 0x0F;
    ubbrl = ubbr & 0xFF;
    switch (port) {
        case 0:
            UBRR0H = ubbrh;
            UBRR0L = ubbrl;
            UCSR0B = _BV(RXEN0) | _BV(TXEN0) | _BV(RXCIE0);
            break;
        case 1:
            UBRR1H = ubbrh;
            UBRR1L = ubbrl;
            UCSR1B = _BV(RXEN1) | _BV(TXEN1) | _BV(RXCIE1);
            break;
        case 2:
            UBRR2H = ubbrh;
            UBRR2L = ubbrl;
            UCSR2B = _BV(RXEN2) | _BV(TXEN2) | _BV(RXCIE2);
            break;
        case 3:
            UBRR3H = ubbrh;
            UBRR3L = ubbrl;
            UCSR3B = _BV(RXEN3) | _BV(TXEN3) | _BV(RXCIE3);
            break;
    }
}

/**
 * 
 */
void uartEnableTxInterrupt (uint8_t port) {
    switch (port) {
        case 0:
            UCSR0B |= _BV(UDRIE0);
            break;
        case 1:
            UCSR1B |= _BV(UDRIE1);
            break;
        case 2:
            UCSR2B |= _BV(UDRIE2);
            break;
        case 3:
            UCSR3B |= _BV(UDRIE3);
            break;  
    }
}

/** Translate a given stream to it's UART port number.
 * 
 */
int8_t uartGetPort (FILE *stream) {
    if (stream == &fstrUart0) return 0;
    if (stream == &fstrUart1) return 1;
    if (stream == &fstrUart2) return 2;
    if (stream == &fstrUart3) return 3;
    return -1;
}

/*** Interrupt Service Routines. ***/

/** Receive data Interrupt Service Routines.
 *
 */
ISR(USART0_RX_vect) {
    atomIntEnter();
    // Check the RX error bits.
    if (UCSR0A & _BV(FE0)) uart[0].flags |= UART_FLAG_FRAMEERR;
    if (UCSR0A & _BV(PE0)) uart[0].flags |= UART_FLAG_PARITYERR;
    if (UCSR0A & _BV(DOR0)) uart[0].flags |= UART_FLAG_RXOVERRUN;
    // Grab the byte now. This forces the interrupt flag to clear.
    uart[0].rxChar = UDR0;
    // Is the RX buffer full?
    if (uart[0].flags & UART_FLAG_RXFULL) {
        // Set the overrun flag, can do no more.
        uart[0].flags |= UART_FLAG_RXOVERRUN;
    } else {
        // Place byte in buffer.
        uart[0].rxBuffer[uart[0].rxHead] = uart[0].rxChar;
        ++uart[0].rxHead;
        if (uart[0].rxHead == UART_RX_BUFSIZE) uart[0].rxHead = 0;
        // If the buffer is full, set flag.
        if (uart[0].rxHead == uart[0].rxTail) uart[0].flags |= UART_FLAG_RXFULL;
        // We have new data
        uart[0].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

ISR(USART1_RX_vect) {
    atomIntEnter();
    if (UCSR1A & _BV(FE1)) uart[1].flags |= UART_FLAG_FRAMEERR;
    if (UCSR1A & _BV(PE1)) uart[1].flags |= UART_FLAG_PARITYERR;
    if (UCSR1A & _BV(DOR1)) uart[1].flags |= UART_FLAG_RXOVERRUN;
    uart[1].rxChar = UDR1;
    if (uart[1].flags & UART_FLAG_RXFULL) {
        uart[1].flags |= UART_FLAG_RXOVERRUN;
    } else {
        uart[1].rxBuffer[uart[1].rxHead++] = uart[1].rxChar;
        if (uart[1].rxHead == UART_RX_BUFSIZE) uart[1].rxHead = 0;
        if (uart[1].rxHead == uart[1].rxTail) uart[1].flags |= UART_FLAG_RXFULL;
        uart[1].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

ISR(USART2_RX_vect) {
    atomIntEnter();
    if (UCSR2A & _BV(FE2)) uart[2].flags |= UART_FLAG_FRAMEERR;
    if (UCSR2A & _BV(PE2)) uart[2].flags |= UART_FLAG_PARITYERR;
    if (UCSR2A & _BV(DOR2)) uart[2].flags |= UART_FLAG_RXOVERRUN;
    uart[2].rxChar = UDR2;
    if (uart[2].flags & UART_FLAG_RXFULL) {
        uart[2].flags |= UART_FLAG_RXOVERRUN;
    } else {
        uart[2].rxBuffer[uart[2].rxHead++] = uart[2].rxChar;
        if (uart[2].rxHead == UART_RX_BUFSIZE) uart[2].rxHead = 0;
        if (uart[2].rxHead == uart[2].rxTail) uart[2].flags |= UART_FLAG_RXFULL;
        uart[2].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

ISR(USART3_RX_vect) {
    atomIntEnter();
    if (UCSR3A & _BV(FE3)) uart[3].flags |= UART_FLAG_FRAMEERR;
    if (UCSR3A & _BV(PE3)) uart[3].flags |= UART_FLAG_PARITYERR;
    if (UCSR3A & _BV(DOR3)) uart[3].flags |= UART_FLAG_RXOVERRUN;
    uart[3].rxChar = UDR3;
    if (uart[3].flags & UART_FLAG_RXFULL) {
        uart[3].flags |= UART_FLAG_RXOVERRUN;
    } else {
        uart[3].rxBuffer[uart[3].rxHead++] = uart[3].rxChar;
        if (uart[3].rxHead == UART_RX_BUFSIZE) uart[3].rxHead = 0;
        if (uart[3].rxHead == uart[3].rxTail) uart[3].flags |= UART_FLAG_RXFULL;
        uart[3].flags |= UART_FLAG_RXDATA;
    }
    atomIntExit(FALSE);
}

/** Transmit Ready Interrupt Service Routines.
 * 
 */
ISR(USART0_UDRE_vect) {
    atomIntEnter();
    // Do we have another byte to TX?
    if (uart[0].flags & UART_FLAG_TXDATA) {
        UDR0 = uart[0].txBuffer[uart[0].txTail++];
        if (uart[0].txTail == UART_TX_BUFSIZE) uart[0].txTail = 0;
        uart[0].flags &= ~UART_FLAG_TXFULL;
        // Is this the last byte?
        if (uart[0].txTail == uart[0].txHead) {
            uart[0].flags &= ~UART_FLAG_TXDATA;
            // Disable interrupt.
            UCSR0B &= ~_BV(UDRIE0);
        }
    }
    atomIntExit(FALSE);
}

ISR(USART1_UDRE_vect) {
    atomIntEnter();
    if (uart[1].flags & UART_FLAG_TXDATA) {
        UDR1 = uart[1].txBuffer[uart[1].txTail++];
        if (uart[1].txTail == UART_TX_BUFSIZE) uart[1].txTail = 0;
        uart[1].flags &= ~UART_FLAG_TXFULL;
        if (uart[1].txTail == uart[1].txHead) {
            uart[1].flags &= ~UART_FLAG_TXDATA;
            UCSR1B &= ~_BV(UDRIE1);
        }
    }
    atomIntExit(FALSE);
}

ISR(USART2_UDRE_vect) {
    atomIntEnter();
    if (uart[2].flags & UART_FLAG_TXDATA) {
        UDR2 = uart[2].txBuffer[uart[2].txTail++];
        if (uart[2].txTail == UART_TX_BUFSIZE) uart[2].txTail = 0;
        uart[2].flags &= ~UART_FLAG_TXFULL;
        if (uart[2].txTail == uart[2].txHead) {
            uart[2].flags &= ~UART_FLAG_TXDATA;
            UCSR2B &= ~_BV(UDRIE2);
        }
    }
    atomIntExit(FALSE);
}

ISR(USART3_UDRE_vect) {
    atomIntEnter();
    if (uart[3].flags & UART_FLAG_TXDATA) {
        UDR3 = uart[3].txBuffer[uart[3].txTail++];
        if (uart[3].txTail == UART_TX_BUFSIZE) uart[3].txTail = 0;
        uart[3].flags &= ~UART_FLAG_TXFULL;
        if (uart[3].txTail == uart[3].txHead) {
            uart[3].flags &= ~UART_FLAG_TXDATA;
            UCSR3B &= ~_BV(UDRIE3);
        }
    }
    atomIntExit(FALSE);
}
