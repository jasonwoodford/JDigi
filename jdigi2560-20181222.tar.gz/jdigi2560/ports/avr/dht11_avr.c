/*
 * dht11_avr.c
 * 
 * Copyright (c) 2017, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: dht11_avr.c,v 1.0 2018/12/18 21:12:00 NST jason_woodford Exp $
 */
#include "dht11_avr.h"

extern DHT11 dht11;

/**
 */
void dht11Init (void) {
    // Set data pin as input, no pull-up.
    DHT11_DATA_DDR &= ~_BV(DHT11_DATA_PIN);
    DHT11_DATA_PORT &= ~_BV(DHT11_DATA_PIN);
    atomTimerDelay(2 * SYSTEM_TICKS_PER_SEC);
}

/** Reads the DHT11 and puts raw values into static memory.
 * 
 * This function disables interrupts to guarantee timimg values. Any busy wait
 * loops MUST use a timeout to prevent OS deadlock, and use CRITICAL_RETURN()
 * to exit the function before re-enabling interrupts.
 */
int8_t dht11Read (void) {
    uint8_t i, j, k;
    uint8_t timeout;
    CRITICAL_STORE;
    
    // Check bus for a high level before starting.
    if ((DHT11_DATA_RW & _BV(DHT11_DATA_PIN)) == 0) return DHT11_ERROR_BUS;
    // Disable interrupts!
    CRITICAL_START();
    // Set data pin as output and set low for 20 ms.
    DHT11_DATA_DDR |= _BV(DHT11_DATA_PIN);
    DHT11_DATA_PORT &= ~_BV(DHT11_DATA_PIN);
    _delay_ms(20);
    // Set data high, as input, no pull-up.
    DHT11_DATA_PORT |= _BV(DHT11_DATA_PIN);
    DHT11_DATA_DDR &= ~_BV(DHT11_DATA_PIN);
    DHT11_DATA_PORT &= ~_BV(DHT11_DATA_PIN);
    // Wait for data to be pulled low, then high again.
    // Set timeout for (10*i) usec.
    timeout = 20;
    while (DHT11_DATA_RW & _BV(DHT11_DATA_PIN)) {
        if (timeout == 0) CRITICAL_RETURN(DHT11_ERROR_NORESP);
        --timeout;
        _delay_us(10);
    }
    while (!(DHT11_DATA_RW & _BV(DHT11_DATA_PIN))) {
        if (timeout == 0) CRITICAL_RETURN(DHT11_ERROR_RESP);
        --timeout;
        _delay_us(10);
    }
    // Wait for data to be pulled low.
    timeout = 10;
    while (DHT11_DATA_RW & _BV(DHT11_DATA_PIN)) {
        if (timeout == 0) CRITICAL_RETURN(DHT11_ERROR_NODATA);
        --timeout;
        _delay_us(10);
    }
    // Now read a stream of data bits.
    j = 0;
    k = 0;
    for (i = 0; i < (8 * DHT11_DATA_SIZE); ++i) {
        // Wait until pulled high.
        timeout = 10;
        while (!(DHT11_DATA_RW & _BV(DHT11_DATA_PIN))) {
            if (timeout == 0) CRITICAL_RETURN(DHT11_ERROR_DATA);
            --timeout;
            _delay_us(10);
        }
        // Now measure how long until pulled low.
        timeout = 10;
        while (DHT11_DATA_RW & _BV(DHT11_DATA_PIN)) {
            if (timeout == 0) CRITICAL_RETURN(DHT11_ERROR_DATA);
            --timeout;
            _delay_us(10);
        }
        // < 30 us is logic 0, ~70us is logic 1.
        if (timeout <= 5) k |= 1;
        if ((i % 8) < 7) {
            k = (k << 1);
        } else {
            dht11.raw[j] = k;
            k = 0;
            ++j;
        }
    }
    // Successfully read all data. Re-enable interrupts!
    CRITICAL_END();
    // Convert the values into the static registers.
    dht11.humd = dht11.raw[0];
    dht11.temp = (int16_t) dht11.raw[2];
    // Return number of bytes read.
    return (int8_t) j;
}
