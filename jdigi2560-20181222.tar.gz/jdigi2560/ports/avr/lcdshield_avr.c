/*
 * lcdshield_avr.c
 * 
 * Low-level definitions for LCD driver.
 * 
 * Copyright (c) 2018, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: lcd_avr.c,v 1.0 2018/12/18 21:12:00 jason_woodford Exp $
 */
#include "lcdshield_avr.h"

static uint8_t const lcdshieldCGRam[8][8] PROGMEM = {
    { 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000 },
    { 0b11000, 0b11000, 0b11000, 0b11000, 0b11000, 0b11000, 0b11000, 0b11000 },
    { 0b11100, 0b11100, 0b11100, 0b11100, 0b11100, 0b11100, 0b11100, 0b11100 },
    { 0b11110, 0b11110, 0b11110, 0b11110, 0b11110, 0b11110, 0b11110, 0b11110 },
    { 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111 },
    { 0b00000, 0b00000, 0b00000, 0b00000, 0b11111, 0b00100, 0b11111, 0b11111 },
    { 0b00000, 0b00000, 0b11111, 0b00100, 0b11111, 0b11111, 0b11111, 0b11111 },
    { 0b11111, 0b00100, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111, 0b11111 }
};

extern APRSConfig config;
extern LCD lcd;

/** Initialize the LCD controller.
 * The initialization sequence has a mandatory timing so the
 * controller can safely recognize the type of interface desired.
 */
void lcdshieldInit (void) {
    uint8_t i, j;
    // Initialize the ports/pins required for read only LCD.
    LCDSHIELD_D4_DDR |= (uint8_t) (1 << LCDSHIELD_D4_PIN);
    LCDSHIELD_D5_DDR |= (uint8_t) (1 << LCDSHIELD_D5_PIN);
    LCDSHIELD_D6_DDR |= (uint8_t) (1 << LCDSHIELD_D6_PIN);
    LCDSHIELD_D7_DDR |= (uint8_t) (1 << LCDSHIELD_D7_PIN);
    LCDSHIELD_RS_DDR |= (uint8_t) (1 << LCDSHIELD_RS_PIN);
    LCDSHIELD_E_DDR |= (uint8_t) (1 << LCDSHIELD_E_PIN);
    // Initialize the backlight control.
    LCDSHIELD_BL_DDR |= (uint8_t) (1 << LCDSHIELD_BL_PIN);
    // 40 ms needed for Vcc = 2.7 V
    _delay_ms(40);
    // 4-bit init sequence
    lcdshieldOutnibble(0x03, 0);
    _delay_ms(5);
    lcdshieldOutnibble(0x03, 0);
    _delay_us(160);
    lcdshieldOutnibble(0x03, 0);
    _delay_us(160);
    lcdshieldOutnibble(0x02, 0);
    _delay_us(160);
    lcdshieldOutcmd(HD44780_FUNCSET | HD44780_FUNCSET_2LINE);
    lcdshieldOutcmd(HD44780_DISPCTRL | HD44780_DISPCTRL_ON | HD44780_DISPCTRL_BLINK);
    lcdshieldOutcmd(HD44780_ENTRYMODE | HD44780_ENTRYMODE_INC);
    // Program the CGRAM character definitions.
    for (i = 0; i < 8; ++i) {
        for (j = 0; j < 8; ++j) {
            lcdshieldOutcmd(HD44780_CGADDR((i << 3) | j));
            lcdshieldOutdata(pgm_read_byte(&lcdshieldCGRam[i][j]));
        }
    }
    // Backlight.
    lcdshieldBacklightSet(config.lcdMode & LCD_FLAGS_BACKLIGHT);
}

/** Write one nibble (4-bits).
 */
void lcdshieldOutnibble (uint8_t n, uint8_t rs) {
    register uint8_t i;
    // D4
    i = LCDSHIELD_D4_PORT;
    (n & 1) ? (i |= (1 << LCDSHIELD_D4_PIN)) : (i &= ~(1 << LCDSHIELD_D4_PIN));
    LCDSHIELD_D4_PORT = i;
    // D5
    i = LCDSHIELD_D5_PORT;
    (n & 2) ? (i |= (1 << LCDSHIELD_D5_PIN)) : (i &= ~(1 << LCDSHIELD_D5_PIN));
    LCDSHIELD_D5_PORT = i;
    // D6, D7, and RS
    i = LCDSHIELD_D6_PORT;
    (n & 4) ? (i |= (1 << LCDSHIELD_D6_PIN)) : (i &= ~(1 << LCDSHIELD_D6_PIN));
    (n & 8) ? (i |= (1 << LCDSHIELD_D7_PIN)) : (i &= ~(1 << LCDSHIELD_D7_PIN));
    (rs == 1) ? (i |= (1 << LCDSHIELD_RS_PIN)) : (i &= ~(1 << LCDSHIELD_RS_PIN));
    LCDSHIELD_D6_PORT = i;
    //
    _delay_us(1);
    LCDSHIELD_E_PORT |= (1 << LCDSHIELD_E_PIN);
    _delay_us(1);
    LCDSHIELD_E_PORT &= ~(1 << LCDSHIELD_E_PIN);
}

/** Send byte to the LCD.
 * Write one byte 4-bits wide twice. rs is the register select:
 * 0 selects instruction register, 1 selects the data register.
 */
void lcdshieldOutbyte (uint8_t b, uint8_t rs) {
    while (atomMutexGet(&lcd.mutex, 0) != ATOM_OK) atomTimerDelay(1);
    lcdshieldOutnibble((b >> 4) & 0x0F, rs);
    lcdshieldOutnibble(b & 0x0F, rs);
    atomMutexPut(&lcd.mutex);
    _delay_us(41);
}

/** Backlight control.
 * If (state > 0) turn backlight on, else turn it off.
 */
void lcdshieldBacklightSet (uint8_t state) {
    if (state > 0) {
        lcd.flags |= LCD_FLAGS_BACKLIGHT;
        LCDSHIELD_BL_PORT |= (uint8_t) (1 << LCDSHIELD_BL_PIN);
    } else {
        lcd.flags &= (uint8_t) ~LCD_FLAGS_BACKLIGHT;
        LCDSHIELD_BL_PORT &= (uint8_t) ~(1 << LCDSHIELD_BL_PIN);
    }
}
