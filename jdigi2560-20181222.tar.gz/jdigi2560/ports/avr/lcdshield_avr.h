/*
 * lcdshield_avr.h
 *
 * Copyright (c) 2017, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: lcdshield_avr.h,v 1.0 2018/12/18 21:12:00 NST jason_woodford Exp $
 */

/** \file */

/** \defgroup lcdshield_avr <lcdshield_avr.h>: LCDshield_avr
 * \code #include <lcdshield_avr.h> \endcode
 * <h3>Introduction to the LCDshield_avr Module</h3>
 *  
 * These are the architecture dependent functions for JDigi's LCDshield module.
 * Please see lcdshield.h for function prototypes.
 */

#ifndef __LCDSHIELD_AVR_H
#define __LCDSHIELD_AVR_H

#include "lcdshield.h"
#include "atomport-private.h"
#include <util/delay.h>

/** \ingroup lcdshield_avr */
/* @{ */
#define LCDSHIELD_D4_PORT   PORTG
#define LCDSHIELD_D4_DDR    DDRG
#define LCDSHIELD_D4_PIN    5
#define LCDSHIELD_D5_PORT   PORTE
#define LCDSHIELD_D5_DDR    DDRE
#define LCDSHIELD_D5_PIN    3
#define LCDSHIELD_D6_PORT   PORTH
#define LCDSHIELD_D6_DDR    DDRH
#define LCDSHIELD_D6_PIN    3
#define LCDSHIELD_D7_PORT   PORTH
#define LCDSHIELD_D7_DDR    DDRH
#define LCDSHIELD_D7_PIN    4
#define LCDSHIELD_RS_PORT   PORTH
#define LCDSHIELD_RS_DDR    DDRH
#define LCDSHIELD_RS_PIN    5
#define LCDSHIELD_E_PORT    PORTH
#define LCDSHIELD_E_DDR     DDRH
#define LCDSHIELD_E_PIN     6
#define LCDSHIELD_BL_PORT   PORTB
#define LCDSHIELD_BL_DDR    DDRB
#define LCDSHIELD_BL_PIN    4

/* @} */
#endif /* __LCDSHIELD_AVR_H */
