/*
 * init.h
 * 
 * Copyright (c) 2017, Jason Woodford, VO1JWW. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. No personal names or organizations' names associated with the
 *    Atomthreads project may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE JDIGI PROJECT AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: init.h,v 1.0 2018/12/18 21:12:00 NST jason_woodford Exp $
 */

/** \file */

/** \defgroup init <init.h>: Init_avr
 * \code #include <init.h> \endcode
 * <h3>Introduction to the Init Module</h3>
 *  
 * This is the architecture dependent initialization sequence for JDigi.
 */

#ifndef __INIT_H__
#define __INIT_H__

#include "atom.h"
#include "adc.h"
#include "aprs.h"
#include "ax25.h"
#include "bitbucket.h"
#include "beacon.h"
#include "bme280.h"
#include "crc.h"
#include "dht11.h"
#include "ds18b20.h"
#include "i2c.h"
#include "lcd.h"
#include "led.h"
#include "menu.h"
#include "nmea.h"
#include "stats.h"
#include "time.h"
#include "thermistor.h"
#include "uart.h"
#include <stdio.h>
#include <stdlib.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>

/** \ingroup init */
/* @{ */
#define INIT_COPYRIGHT  "\
\n***\
\nJDigi AX.25/APRS Smart Digipeater v0.99pre\
\n(C)2018 Jason Woodford, VO1JWW.\
\nUses the AtomThreads scheduler, (C)2010 Kelvin Lawson.\
\nGNU Time functions (C)2012 Michael Duane Rice.\
\nAll rights reserved.\
\n***"

void sysInit (char *buf);        ///< Initialize system.

/* @} */
#endif /* __INIT_H__ */
